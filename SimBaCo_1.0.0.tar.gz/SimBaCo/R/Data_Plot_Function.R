#' Prepare Data to Plot a Kaplan-Meier-Plot
#'
#'
#' @import cluster
#' @import comorbidity
#' @import varhandle
#' @import dplyr
#' @import formattable
#' @import ggplot2
#' @import feather
#' @import purrr
#' @import data.table
#' @import shiny
#' @import rlist
#' @import RColorBrewer
#' @import gridExtra
#' @import forcats
#' @import furrr
#' @import foreach
#' @import doParallel
#' @import stringr
#' @import parallel
#' @import snow
#' @import survival
#' @import survminer
#' @import pROC
#' @import factoextra
#' @import readr
#' @import Rtsne
#' @import iterators
#' @import UBL
#' @import svMisc
#' @import lubridate
#'
#'
#' @param ATC_INPUT ATC_INPUT, for the ATC codes to compare in the Kaplan-Meier plot (grepl allowed).
#' @param ICD_INPUT ICD_INPUT, the ICD code to use if OUTCOME is set to ICD or DEATH_AND_ICD
#' @param OUTCOME OUTCOME, the outcome in the Kaplan-Meier-Plot. (Could be set to DEATH, ICD, DEATH_AND_ICD)
#' @param PRESCRIPTION PRESCRIPTION, the name of the data frame containing the prescription data
#' @param PRESCRIPTION_ID_COLNAME PRESCRIPTION_ID_COLNAME, the name of the column where the IDs are stored in the data frame prescription
#' @param PRESCRIPTION_CODE_COLNAME PRESCRIPTION_CODE_COLNAME, the name of the column containing the ATC codes in the data frame prescription
#' @param PRESCRIPTION_CODE_DATUM_COLNAME PRESCRIPTION_CODE_DATUM_COLNAME, the name of the column containing the prescription dates in the data frame prescription
#' @param PRESCRIPTION_INDEXDATUM_COLNAME PRESCRIPTION_INDEXDATUM_COLNAME, the name of the column containing the patient index dates in the data frame prescription
#' @param DIAGNOSES DIAGNOSES, name of the data frame containing the diagnoses
#' @param DIAGNOSES_ID_COLNAME DIAGNOSES_ID_COLNAME, name of the column in the data frame DIAGNOSES containing the IDs
#' @param DIAGNOSES_CODE_COLNAME DIAGNOSES_CODE_COLNAME, name of the column in the data frame DIAGNOSES containing the ICD codes
#' @param DIAGNOSES_CODE_DATUM_COLNAME DIAGNOSES_CODE_DATUM_COLNAME, name of the column in the data frame DIAGNOSES containing the diagnoses' dates
#' @param DIAGNOSES_INDEXDATUM_COLNAME DIAGNOSES_INDEXDATUM_COLNAME, name of the data frame containing the patient index dates
#' @param INSURANTS INSURANTS, name of the data frame containing the insurant data
#' @param INSURANTS_ID_COLNAME INSURANTS_ID_COLNAME, name of the column in the data frame INSURANTS containing the patient IDs
#' @param INSURANTS_CODE_COLNAME INSURANTS_CODE_COLNAME, name of the column in the data frame INSURANTS containing the sex of the patients
#' @param INSURANTS_CODE_DATUM_COLNAME INSURANTS_CODE_DATUM_COLNAME, name of the column in the data frame INSURANTS containing the death dates
#' @param INSURANTS_INDEXDATUM_COLNAME INSURANTS_INDEXDATUM_COLNAME, name of the column in the data frame INSURANTS containing the patient index dates
#'
#' @return rearranged data ready to plot!
#'
#' @author Lucas Wirbka, \email{Lucas.Wirbka@@med.uni-heidelberg.de}
#'
#' @examples
#'
#'plotlyyy <- Data_Plot_Similarity( ATC_INPUT = c("^J01M","^J01MA12"),
#'                                  ICD_INPUT = c("^A41"),
#'                                  OUTCOME = "DEATH",
#'                                  PRESCRIPTION = VO_ready2,
#'                                  PRESCRIPTION_ID_COLNAME = "ID",
#'                                  PRESCRIPTION_CODE_COLNAME = "CODE",
#'                                  PRESCRIPTION_CODE_DATUM_COLNAME = "CODE_DATUM",
#'                                  PRESCRIPTION_INDEXDATUM_COLNAME = "INDEXDATUM",
#'                                  DIAGNOSES = Diag_ready2,
#'                                  DIAGNOSES_ID_COLNAME = "ID",
#'                                  DIAGNOSES_CODE_COLNAME = "CODE",
#'                                  DIAGNOSES_CODE_DATUM_COLNAME = "CODE_DATUM",
#'                                  DIAGNOSES_INDEXDATUM_COLNAME = "INDEXDATUM",
#'                                  INSURANTS = VERS_ready2,
#'                                  INSURANTS_ID_COLNAME = "ID",
#'                                  INSURANTS_CODE_COLNAME = "CODE",
#'                                  INSURANTS_CODE_DATUM_COLNAME = "CODE_DATUM",
#'                                  INSURANTS_INDEXDATUM_COLNAME = "INDEXDATUM")
#'
#'
#'df <- plotlyyy
#'
#'
#'surv_object <-  Surv(time = df$TIME, event = df$OUTCOME)
#'fit1 <- survfit(surv_object ~ df$CODE, data = df)
#'plot1 <- ggsurvplot(fit1, data = df, pval = TRUE)
#'
#'plot1
#'
#' @export
Data_Plot_Similarity <- function(ATC_INPUT = c(),ICD_INPUT = c(""), OUTCOME = c(), PRESCRIPTION = c(), PRESCRIPTION_ID_COLNAME = c(), PRESCRIPTION_CODE_COLNAME = c(), PRESCRIPTION_CODE_DATUM_COLNAME = c(),PRESCRIPTION_INDEXDATUM_COLNAME = C(), DIAGNOSES = c(), DIAGNOSES_ID_COLNAME = c(), DIAGNOSES_CODE_COLNAME = c(), DIAGNOSES_CODE_DATUM_COLNAME = c(),DIAGNOSES_INDEXDATUM_COLNAME = C(), INSURANTS = c(), INSURANTS_ID_COLNAME = c(), INSURANTS_CODE_COLNAME = c(), INSURANTS_CODE_DATUM_COLNAME = c(), INSURANTS_INDEXDATUM_COLNAME = C()) {
  options(warn=-1)
  vector.is.empty <- function(x) return(length(x) ==0)

  if(vector.is.empty(PRESCRIPTION)==TRUE){stop("Please Enter PRESCRIPTION")}
  if(vector.is.empty(PRESCRIPTION_ID_COLNAME)==TRUE){stop("Please Enter PRESCRIPTION_ID_COLNAME")}
  if(vector.is.empty(PRESCRIPTION_CODE_COLNAME)==TRUE){stop("Please Enter PRESCRIPTION_CODE_COLNAME")}
  if(vector.is.empty(PRESCRIPTION_CODE_DATUM_COLNAME)==TRUE){stop("Please Enter PRESCRIPTION_CODE_DATUM_COLNAME")}
  if(vector.is.empty(PRESCRIPTION_INDEXDATUM_COLNAME)==TRUE){stop("Please Enter PRESCRIPTION_INDEXDATUM_COLNAME")}

  if(vector.is.empty(DIAGNOSES)==TRUE){stop("Please Enter DIAGNOSES")}
  if(vector.is.empty(DIAGNOSES_ID_COLNAME)==TRUE){stop("Please Enter DIAGNOSES_ID_COLNAME")}
  if(vector.is.empty(DIAGNOSES_CODE_COLNAME)==TRUE){stop("Please Enter DIAGNOSES_CODE_COLNAME")}
  if(vector.is.empty(DIAGNOSES_CODE_DATUM_COLNAME)==TRUE){stop("Please Enter DIAGNOSES_CODE_DATUM_COLNAME")}
  if(vector.is.empty(DIAGNOSES_INDEXDATUM_COLNAME)==TRUE){stop("Please Enter DIAGNOSES_INDEXDATUM_COLNAME")}

  if(vector.is.empty(INSURANTS)==TRUE){stop("Please Enter INSURANTS")}
  if(vector.is.empty(INSURANTS_ID_COLNAME)==TRUE){stop("Please Enter INSURANTS_ID_COLNAME")}

  if(OUTCOME == "DEATH" | OUTCOME == "DEATH_AND_ICD"){
    if(vector.is.empty(INSURANTS_CODE_COLNAME)==TRUE){stop("Please Enter INSURANTS_CODE_COLNAME")}
    if(vector.is.empty(INSURANTS_CODE_DATUM_COLNAME)==TRUE){stop("Please Enter INSURANTS_CODE_DATUM_COLNAME")}
  } else { if(vector.is.empty(INSURANTS_CODE_COLNAME)==TRUE){INSURANTS$CODE <- 1} else{INSURANTS$CODE <- INSURANTS[[INSURANTS_CODE_COLNAME]]}
    if(vector.is.empty(INSURANTS_CODE_DATUM_COLNAME)==TRUE){INSURANTS$CODE_DATUM <- as.Date("99991201",format = "%Y%m%d")}else{INSURANTS$CODE_DATUM <- INSURANTS[[INSURANTS_CODE_DATUM_COLNAME]]}
  }

  if(vector.is.empty(INSURANTS_INDEXDATUM_COLNAME)==TRUE){stop("Please Enter INSURANTS_INDEXDATUM_COLNAME")}

  if(vector.is.empty(ATC_INPUT)==TRUE){stop("Please Enter ATC_INPUT")}
  if(vector.is.empty(ICD_INPUT)==TRUE){stop("Please Enter ICD_INPUT")}
  if(vector.is.empty(OUTCOME)==TRUE){stop("Please Enter OUTCOME (DEATH, ICD, DEATH_AND_ICD)")}

  if(is.character(PRESCRIPTION_ID_COLNAME)==FALSE){stop("Type of PRESCRIPTION_ID_COLNAME must be Character")}
  if(is.character(PRESCRIPTION_CODE_COLNAME)==FALSE){stop("Type of PRESCRIPTION_CODE_COLNAME must be Character")}
  if(is.character(PRESCRIPTION_CODE_DATUM_COLNAME)==FALSE){stop("Type of PRESCRIPTION_CODE_DATUM_COLNAME must be Character")}
  if(is.character(PRESCRIPTION_INDEXDATUM_COLNAME)==FALSE){stop("Type of PRESCRIPTION_INDEXDATUM_COLNAME must be Character")}

  if(is.character(DIAGNOSES_ID_COLNAME)==FALSE){stop("Type of DIAGNOSES_ID_COLNAME must be Character")}
  if(is.character(DIAGNOSES_CODE_COLNAME)==FALSE){stop("Type of DIAGNOSES_CODE_COLNAME must be Character")}
  if(is.character(DIAGNOSES_CODE_DATUM_COLNAME)==FALSE){stop("Type of DIAGNOSES_CODE_DATUM_COLNAME must be Character")}
  if(is.character(DIAGNOSES_INDEXDATUM_COLNAME)==FALSE){stop("Type of DIAGNOSES_INDEXDATUM_COLNAME must be Character")}

  if(is.character(INSURANTS_ID_COLNAME)==FALSE){stop("Type of INSURANTS_ID_COLNAME must be Character")}
  if(OUTCOME == "DEATH" | OUTCOME == "DEATH_AND_ICD"){
    if(is.character(INSURANTS_CODE_COLNAME)==FALSE){stop("Type of INSURANTS_CODE_COLNAME must be Character")}
    if(is.character(INSURANTS_CODE_DATUM_COLNAME)==FALSE){stop("Type of INSURANTS_CODE_DATUM_COLNAME must be Character")}
  }
  if(is.character(INSURANTS_INDEXDATUM_COLNAME)==FALSE){stop("Type of INSURANTS_INDEXDATUM_COLNAME must be Character")}

  if(is.character(ATC_INPUT)==FALSE){stop("Type of ATC_INPUT must be Character")}
  if(is.character(ICD_INPUT)==FALSE){stop("Type of ICD_INPUT must be Character")}
  if(is.character(OUTCOME)==FALSE){stop("Type of OUTCOME must be Character")}

  if(OUTCOME == "DEATH"){}
  else if(OUTCOME == "ICD"){}
  else if(OUTCOME == "DEATH_AND_ICD"){}
  else {stop("Please Enter OUTCOME (DEATH, ICD, DEATH_AND_ICD)")}

  PRESCRIPTION$ID <- PRESCRIPTION[[PRESCRIPTION_ID_COLNAME]]
  PRESCRIPTION$CODE <- PRESCRIPTION[[PRESCRIPTION_CODE_COLNAME]]
  PRESCRIPTION$CODE_DATUM <- PRESCRIPTION[[PRESCRIPTION_CODE_DATUM_COLNAME]]
  PRESCRIPTION$INDEXDATUM <- PRESCRIPTION[[PRESCRIPTION_INDEXDATUM_COLNAME]]

  DIAGNOSES$ID <- DIAGNOSES[[DIAGNOSES_ID_COLNAME]]
  DIAGNOSES$CODE <- DIAGNOSES[[DIAGNOSES_CODE_COLNAME]]
  DIAGNOSES$CODE_DATUM <- DIAGNOSES[[DIAGNOSES_CODE_DATUM_COLNAME]]
  DIAGNOSES$INDEXDATUM <- DIAGNOSES[[DIAGNOSES_INDEXDATUM_COLNAME]]

  INSURANTS$ID <- INSURANTS[[INSURANTS_ID_COLNAME]]
  INSURANTS$INDEXDATUM <- INSURANTS[[INSURANTS_INDEXDATUM_COLNAME]]

  count_ATC <- function(datalist){
    intermediate <- datalist %>%
      select(ID,CODE) %>%
      distinct()
    datalist$COUNT_ATC <- nrow(intermediate)
    return(datalist)
  }

  final1 <- PRESCRIPTION %>%
    filter(grepl(paste(ATC_INPUT, collapse="|"), PRESCRIPTION$CODE))

  datalist <- split(final1, final1$ID)
  datalist <- map(datalist,count_ATC)
  datalist <- rbindlist(datalist)

  datalist <- datalist %>%
    filter(datalist$COUNT_ATC == 1)

  datalist$TIME <- datalist$CODE_DATUM - datalist$INDEXDATUM

  datalist <- datalist %>%
    select(ID,CODE,TIME)

  datalist$OUTCOME <- 0

  INTERMEDIATE_FRAME <- datalist

  if(OUTCOME == "DEATH_AND_ICD"){

    get_shorter_Time  <- function(datalist) {
      ID <- unique(datalist$ID)
      OUTCOME <- unique(datalist$OUTCOME.x)
      min1 <- min(datalist$TIME1)
      min2 <- min(datalist$TIME2)
      TIME <- unique(datalist$TIME)
      if(min1 > min2){
        TIME <- min2
      }
      if(min1 < min2){
        TIME <- min1
      }
      df <- data.frame(ID,TIME,OUTCOME)
      return(df)
    }
    delete_after_one <- function(datalist) {
      interrim <- datalist %>%
        filter(datalist$OUTCOME == 1)
      if(nrow(interrim)==1){
        maxDATe <- interrim$TIME
        datalist <- datalist %>%
          filter(datalist$TIME <= maxDATe)}
      return(datalist)
    }

    INSURANTS$TIME1 <- INSURANTS$CODE_DATUM - INSURANTS$INDEXDATUM

    INSURANTS <- INSURANTS %>%
      filter(INSURANTS$TIME1 < 50000)

    INSURANTS$OUTCOME <- 1

    INSURANTS <- INSURANTS %>%
      select(ID,TIME1,OUTCOME) %>%
      distinct()

    DIAGNOSES <- DIAGNOSES %>%
      filter(grepl(paste(ICD_INPUT, collapse="|"), DIAGNOSES$CODE))

    DIAGNOSES$TIME2 <- DIAGNOSES$CODE_DATUM - DIAGNOSES$INDEXDATUM

    DIAGNOSES$OUTCOME <- 1

    DIAGNOSES <- DIAGNOSES %>%
      select(ID,TIME2,OUTCOME) %>%
      distinct()

    final_outcome <- merge(INSURANTS,DIAGNOSES, by = "ID")

    final_outcome$TIME1 <- as.numeric(final_outcome$TIME1)
    final_outcome$TIME2 <- as.numeric(final_outcome$TIME2)
    final_outcome$TIME <- 0

    datalist <- split(final_outcome,final_outcome$ID)
    datalist <- map(datalist,get_shorter_Time)
    final_outcome <- rbindlist(datalist)

    To_Match <- INTERMEDIATE_FRAME %>%
      select(ID,CODE) %>%
      distinct()

    final_outcome <- merge(final_outcome,To_Match, by = "ID")

    final_outcome <- bind_rows(final_outcome,INTERMEDIATE_FRAME)

    final_outcome$TIME <- as.numeric(final_outcome$TIME)

    datalist <- split(final_outcome,final_outcome$ID)
    datalist <- map(datalist,delete_after_one)
    final_outcome <- rbindlist(datalist)
  }
  else if(OUTCOME == "DEATH"){

    delete_after_one <- function(datalist) {

      interrim <- datalist %>%
        filter(datalist$OUTCOME == 1)

      if(nrow(interrim)>=1){
        maxDATe <- interrim$TIME
        datalist <- datalist %>%
          filter(datalist$TIME <= maxDATe)}

      return(datalist)
    }

    INSURANTS$TIME1 <- INSURANTS$CODE_DATUM - INSURANTS$INDEXDATUM

    INSURANTS <- INSURANTS %>%
      filter(INSURANTS$TIME1 < 50000)

    INSURANTS$OUTCOME <- 1

    INSURANTS <- INSURANTS %>%
      select(ID,TIME1,OUTCOME) %>%
      distinct()

    final_outcome <- INSURANTS

    final_outcome <- final_outcome %>%
      rename(TIME = TIME1)

    To_Match <- INTERMEDIATE_FRAME %>%
      select(ID,CODE) %>%
      distinct()

    final_outcome <- merge(final_outcome,To_Match, by = "ID")

    final_outcome <- bind_rows(final_outcome,INTERMEDIATE_FRAME)

    final_outcome$TIME <- as.numeric(final_outcome$TIME)



    datalist <- split(final_outcome,final_outcome$ID)
    datalist <- map(datalist,delete_after_one)
    final_outcome <- rbindlist(datalist)

  }
  else if (OUTCOME == "ICD"){
    get_shorter_Time  <- function(datalist) {
      ID <- unique(datalist$ID)
      OUTCOME <- unique(datalist$OUTCOME)
      min1 <- min(datalist$TIME)
      min2 <- min(datalist$TIME2)
      TIME2 <- min2
      df <- data.frame(ID,TIME2,OUTCOME)
      return(df)
    }
    delete_after_one <- function(datalist) {

      interrim <- datalist %>%
        filter(datalist$OUTCOME == 1)

      if(nrow(interrim)>=1){
        maxDATe <- interrim$TIME
        datalist <- datalist %>%
          filter(datalist$TIME <= maxDATe)}

      return(datalist)
    }

    DIAGNOSES <- DIAGNOSES %>%
      filter(grepl(paste(ICD_INPUT, collapse="|"), DIAGNOSES$CODE))

    DIAGNOSES$TIME2 <- DIAGNOSES$CODE_DATUM - DIAGNOSES$INDEXDATUM

    DIAGNOSES$OUTCOME <- 1

    DIAGNOSES <- DIAGNOSES %>%
      select(ID,TIME2,OUTCOME) %>%
      distinct()

    final_outcome <- DIAGNOSES

    final_outcome$TIME2 <- as.numeric(final_outcome$TIME2)

    datalist <- split(final_outcome,final_outcome$ID)
    datalist <- map(datalist,get_shorter_Time)
    final_outcome <- rbindlist(datalist)

    final_outcome <- final_outcome %>%
      rename(TIME = TIME2)

    To_Match <- INTERMEDIATE_FRAME %>%
      select(ID,CODE) %>%
      distinct()

    final_outcome <- merge(final_outcome,To_Match, by = "ID")

    final_outcome <- bind_rows(final_outcome,INTERMEDIATE_FRAME)

    final_outcome$TIME <- as.numeric(final_outcome$TIME)

    datalist <- split(final_outcome,final_outcome$ID)
    datalist <- map(datalist,delete_after_one)
    final_outcome <- rbindlist(datalist)

  }
  else {
    stop("PLEASE ENTER Right Code")
  }
  options(warn=0)
  return(final_outcome)}



