#' Search After Index
#'
#' Search dataframes according to dates
#'
#' @import cluster
#' @import comorbidity
#' @import varhandle
#' @import dplyr
#' @import formattable
#' @import ggplot2
#' @import feather
#' @import purrr
#' @import data.table
#' @import shiny
#' @import rlist
#' @import RColorBrewer
#' @import gridExtra
#' @import forcats
#' @import furrr
#' @import foreach
#' @import doParallel
#' @import stringr
#' @import parallel
#' @import snow
#' @import survival
#' @import survminer
#' @import pROC
#' @import factoextra
#' @import readr
#' @import Rtsne
#' @import iterators
#' @import UBL
#' @import svMisc
#' @import lubridate
#'
#'
#' @param DF1 DF1, the name of the first dataframe
#' @param DF2 DF2, the name of the second dataframe
#' @param DF1_COLNAME DF1_COLNAME, the column in the first dataframe containing the ids
#' @param DF1_DATENAME DF1_DATENAME, the column in the first dataframe containing the dates
#' @param DF1_CODE DF1_CODE, the column in the first dataframe containing the codes
#' @param DF2_COLNAME DF2_COLNAME, the column in the second dataframe containing the ids
#' @param DF2_DATENAME DF2_DATENAME, the column in the second dataframe containing the dates
#'
#' @return DF1 searched according to the Arguments in DF2
#'
#' @author Lucas Wirbka, \email{Lucas.Wirbka@@med.uni-heidelberg.de}
#'
#' @examples
#'
#'VO_ready1 <- Search_After_Index(DF1 = VO_ready,
#'                                DF1_COLNAME = "Versid",
#'                                DF1_DATENAME = "Verordnungsdatum",
#'                                DF1_CODE = "ATC",
#'                                DF2 = Index_ready1,
#'                                DF2_COLNAME = "Versid",
#'                                DF2_DATENAME = "datumIndex")
#'
#' @export
Search_After_Index <- function(DF1 = c(),DF2 = c(), DF1_COLNAME = c(), DF1_DATENAME = c(), DF1_CODE = c(), DF2_COLNAME = c(), DF2_DATENAME = c()) {
  vector.is.empty <- function(x) return(length(x) ==0)

  if(vector.is.empty(DF1)==TRUE){stop("Please Enter DF1")}
  if(vector.is.empty(DF2)==TRUE){stop("Please Enter DF2")}
  if(vector.is.empty(DF1_COLNAME)==TRUE){stop("Please Enter DF1_COLNAME")}
  if(vector.is.empty(DF2_COLNAME)==TRUE){stop("Please Enter DF2_COLNAME")}
  if(vector.is.empty(DF1_DATENAME)==TRUE){stop("Please Enter DF1_DATENAME")}
  if(vector.is.empty(DF2_DATENAME)==TRUE){stop("Please Enter DF2_DATENAME")}
  if(vector.is.empty(DF1_CODE)==TRUE){stop("Please Enter DF1_CODE")}

  DF1$ID <- DF1[[DF1_COLNAME]]
  DF2$ID <- DF2[[DF2_COLNAME]]

  DF1$DATUM <- DF1[[DF1_DATENAME]]
  DF2$DATUM <- DF2[[DF2_DATENAME]]

  if(is.Date(DF1$DATUM) == FALSE){stop("Please Enter DF1_DATENAME as DATE with Structure %Y%m%d")}
  if(is.Date(DF2$DATUM) == FALSE){stop("Please Enter DF2_DATENAME as DATE with Structure %Y%m%d")}

  DF1$CODE <- DF1[[DF1_CODE]]

  DFcut <- merge(DF1,DF2, by = "ID")

  DFcut <- DFcut %>%
    select(ID,CODE,DATUM.x,DATUM.y) %>%
    rename(CODE_DATUM = DATUM.x,INDEXDATUM = DATUM.y) %>%
    distinct()

  DFcut <- DFcut %>%
    filter(DFcut$CODE_DATUM > DFcut$INDEXDATUM)

  return(DFcut)
}
