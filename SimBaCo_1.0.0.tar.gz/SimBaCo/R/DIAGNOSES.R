#' Diagnoses of 10000 patients
#'
#' A dataset containing the diagnoses and diagnose dates of almost 10000
#' patients. The variables are as follows:
#'
#' \itemize{
#'   \item ID ID's of the patients.
#'   \item ICD ICD-10 Codes of the diagnoses.
#'   \item DATE Date, at which the diagnose was established.
#' }
#'
#' @docType data
#' @keywords datasets
#' @name DIAGNOSES
#' @usage data(DIAGNOSES)
#' @format A data frame with 134974 rows and 3 variables
NULL
