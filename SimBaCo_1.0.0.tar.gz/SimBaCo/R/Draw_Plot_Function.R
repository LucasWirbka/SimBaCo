#' Draw Plot Function
#'
#' Draw a nice Scaled-Chart plot
#'
#' @import cluster
#' @import comorbidity
#' @import varhandle
#' @import dplyr
#' @import formattable
#' @import ggplot2
#' @import feather
#' @import purrr
#' @import data.table
#' @import shiny
#' @import rlist
#' @import RColorBrewer
#' @import gridExtra
#' @import forcats
#' @import furrr
#' @import foreach
#' @import doParallel
#' @import stringr
#' @import parallel
#' @import snow
#' @import survival
#' @import survminer
#' @import pROC
#' @import factoextra
#' @import readr
#' @import Rtsne
#' @import iterators
#' @import UBL
#' @import svMisc
#' @import lubridate
#'
#' @param SELECT_COMORBIDITY SELECT_COMORBIDITY, could be some of the comorbidities listed in the comorbidity package.
#' @param PATIENT_SIMILAR_BIRTH_YEAR PATIENT_SIMILAR_BIRTH_YEAR, the year of birth for patient to match for.
#' @param PATIENT_SIMILAR_SEX PATIENT_SIMILAR_SEX, the sex of the patient to match for.
#' @param PATIENT_SIMILAR_INDEXDATE PATIENT_SIMILAR_INDEXDATE, the index date of the patient to match for.
#' @param PATIENT_SIMILAR_INDEXDATE_FORMAT PATIENT_SIMILAR_INDEXDATE_FORMAT, date format of the field PATIENT_SIMILAR_INDEXDATE.
#' @param PATIENT_SIMILAR_ATC PATIENT_SIMILAR_ATC, the ATC codes for the patient to match for.
#' @param PATIENT_SIMILAR_ATC_COUNT PATIENT_SIMILAR_ATC_MENGE, the quantity of the ATC codes in the field PATIENT_SIMILAR_ATC.
#' @param PATIENT_SIMILAR_ICD PATIENT_SIMILAR_ICD, the ICD codes for the patient to match for.
#' @param PRESCRIPTION PRESCRIPTION, the name of the data frame containing the prescription data
#' @param PRESCRIPTION_ID_COLNAME PRESCRIPTION_ID_COLNAME, the name of the column where the IDs in the data frame prescription
#' @param PRESCRIPTION_ATC_COLNAME PRESCRIPTION_ATC_COLNAME, the name of the column containing the ATC codes in the data frame prescription
#' @param DIAGNOSES DIAGNOSES, name of the data frame containing the diagnoses.
#' @param DIAGNOSES_ID_COLNAME DIAGNOSES_ID_COLNAME, name of the column in the data frame DIAGNOSES containing the IDs
#' @param DIAGNOSES_ICD_COLNAME DIAGNOSES_ICD_COLNAME, name of the column in the data frame DIAGNOSES containing the ICD codes
#' @param DIAGNOSES_ICD_TYPE DIAGNOSES_ICD_TYPE, can be set to "icd10" or "icd09"
#' @param INSURANTS INSURANTS, name of the data frame containing the insurants' data
#' @param INSURANTS_ID_COLNAME INSURANTS_ID_COLNAME, name of the column in the data frame INSURANTS containing the patient IDs
#' @param INSURANTS_BIRTH_YEAR_COLNAME INSURANTS_BIRTH_YEAR_COLNAME, name of the column in the data frame INSURANTS containing the patients' year of birth
#' @param INSURANTS_SEX_COLNAME INSURANTS_SEX_COLNAME, name of the column in the data frame INSURANTS containing the sex of the patients
#' @param INSURANTS_SEX_MALE INSURANTS_SEX_MALE, which symbol is used in INSURANTS_SEX_COLNAME to classify for male
#' @param INSURANTS_SEX_FEMALE INSURANTS_SEX_FEMALE, which symbol is used in INSURANTS_SEX_COLNAME to classify for female
#' @param INSURANTS_INDEXDATE_COLNAME INSURANTS_INDEXDATUM_COLNAME, name of the column in the data frame INSURANTS containing the patient index dates
#' @param Change_Name_Plot Use Change_Name_Plot to change the names of the scale chart on the x-axis; format = ("a","b")
#'
#' @return nice plot!
#'
#' @author Lucas Wirbka \email{Lucas.Wirbka@@med.uni-heidelberg.de}
#'
#' @examples
#'
#'Baseplot <- Draw_Scale_Chart(SELECT_COMORBIDITY = c("chf","carit","hypc"),
#'                              PATIENT_SIMILAR_BIRTH_YEAR = 1930,
#'                              PATIENT_SIMILAR_SEX = "2",                                                                                            #Format des Feldes: Character
#'                              PATIENT_SIMILAR_INDEXDATE = "20191030",
#'                              PATIENT_SIMILAR_INDEXDATE_FORMAT = "%Y%m%d",
#'                              PATIENT_SIMILAR_ATC = c("^C10","^D"),
#'                              PATIENT_SIMILAR_ATC_COUNT = c(10,3),
#'                              PATIENT_SIMILAR_ICD = c("I480","I101"),
#'                              PRESCRIPTION = VO_ready,
#'                              PRESCRIPTION_ATC_COLNAME = "ATC",
#'                              PRESCRIPTION_ID_COLNAME = "Versid",
#'                              DIAGNOSES = Diag_ready,
#'                              DIAGNOSES_ICD_COLNAME = "ICD",
#'                              DIAGNOSES_ID_COLNAME = "Versid.x",
#'                              DIAGNOSES_ICD_TYPE = "icd10",
#'                              INSURANTS = VERS_ready,
#'                              INSURANTS_ID_COLNAME = "Versid",
#'                              INSURANTS_BIRTH_YEAR_COLNAME = "Geburtsjahr",
#'                              INSURANTS_SEX_COLNAME = "Geschlecht",
#'                              INSURANTS_SEX_MALE = "2",
#'                              INSURANTS_SEX_FEMALE = "1",
#'                              INSURANTS_INDEXDATE_COLNAME = "datumIndex")
#'Baseplot
#'
#'
#' @export
Draw_Scale_Chart <- function(PATIENT_SIMILAR_ATC_COUNT=c(1), PATIENT_DIAGNOSE_TO_DRAW = c(), PAT_SIMILAR_ID = 999999999999, NEAREST_PERCENT_AMOUNT = 10, PATIENT_SIMILAR_INDEXDATE = c("99991231"), PATIENT_SIMILAR_INDEXDATE_FORMAT = c("%Y%m%d"), PATIENT_SIMILAR_BIRTH_YEAR = c(9999), PATIENT_SIMILAR_SEX = c("1"),PATIENT_SIMILAR_ATC = c("ZZZ"),PATIENT_SIMILAR_ICD = c("z"),PRESCRIPTION = c(),PRESCRIPTION_ATC_COLNAME = c(),PRESCRIPTION_ID_COLNAME = c(),DIAGNOSES = c(),DIAGNOSES_ICD_COLNAME = c(),DIAGNOSES_ID_COLNAME = c(),INSURANTS,INSURANTS_ID_COLNAME = c(),INSURANTS_BIRTH_YEAR_COLNAME = c(), DIAGNOSES_ICD_TYPE = c(), INSURANTS_SEX_COLNAME = c(), INSURANTS_INDEXDATE_COLNAME = c(), SELECT_COMORBIDITY = c("score"), INSURANTS_SEX_MALE = c("2"), INSURANTS_SEX_FEMALE = c("1"), Change_Name_Plot = c()){
  options(warn=-1)
  vector.is.empty <- function(x) return(length(x) ==0)

  if(PATIENT_SIMILAR_ICD != "z" && SELECT_COMORBIDITY == "score"){
    stop("Enter Comorbidity to look in Patients Diagnoses for! If you wouldnt like to use Elixhauser, use the PATIENT_DIAGNOSE_TO_DRAW function")
  }
  if(PATIENT_SIMILAR_ICD == "z" && SELECT_COMORBIDITY != "score"){
    stop("Enter Diagnoses in PATIENT_SIMILAR_ICD to calculate Comorbidity!")
  }

  progress(0, max.value = 10, progress.bar = TRUE, char = "|",init = TRUE, console = TRUE, gui = TRUE)
  #______________________________________________________________________________________Cases and Varcheck
  '%ni%' <- Negate('%in%')
  insertRow <- function(existingDF, newrow, r) {
    existingDF[seq(r+1,nrow(existingDF)+1),] <- existingDF[seq(r,nrow(existingDF)),]
    existingDF[r,] <- newrow
    existingDF
  }
  make_scale_data <- function(Pat=Patient, vars=c("sex", "age"), studies=NULL){
    res_data <- data.frame(variable=character(), category=character(), value=numeric())
    ann_text <- data.frame(variable = character(),category = character(), value=numeric(), alphacat= numeric(), LAB = character())

    for (v in vars) {
      temp_data <- data.frame(variable=character(), category=character(), value=numeric())
      Pat_value <- as.character(Patient[,v])
      eval(parse(text=(paste("type <- as.character(", v, "$type)",sep=""))))

      if (type == "categorical") {

        eval(parse(text=(paste("format <- as.character(", v, "$format)",sep=""))))

        if (format !=  "percent") {
          eval(parse(text=(paste(v, "[,which(names(", v, ") %ni% c('type', 'format', 'N') )] <- ", v, "[,which(names(", v, ") %ni% c('type', 'format', 'N') )] / ", v, "$N", sep=""))))
        }

        eval(parse(text=(paste("position <- ifelse(", v, "$", Pat_value, "> 0.5, 'high', 'low')",sep=""))))

        eval(parse(text=(paste("number_of_categories <- ncol(", v, "[,which(names(", v, ") %ni% c('type', 'format', 'N'))])", sep=""))))

        for (i in 1:number_of_categories) {
          eval(parse(text=(paste("temp_data <- rbind(temp_data, data.frame(variable='", v, "', category=names(", v, ")[2+i], value=", v, "[1,2+i]))", sep=""))))
        }
        temp_data$category <- as.character(temp_data$category)
        eval(parse(text=(paste("newrow <- c('", v, "', category='blank', value=0)", sep=""))))

        temp_data <- insertRow(temp_data, newrow, 1)
        temp_data$value <- as.numeric(temp_data$value)
        temp_data <- temp_data[order(temp_data$value),]

        if (position == "low") {
          temp_data[which(temp_data$category == "blank"),]$value <- 1 - (0.5 * as.numeric(temp_data[which(temp_data$category == Pat_value),]$value))
          # order tempdata
          temp_data$category <- factor(temp_data$category, levels = c(as.character(temp_data$category)[which(temp_data$category %ni% c(Pat_value, 'blank' ))], Pat_value, 'blank'))
          #  temp_data[which(temp_data$category != "blank"),]$value <- as.numeric(temp_data[which(temp_data$category != "blank"),]$value) + as.numeric(temp_data[which(temp_data$category == "blank"),]$value)
        } else {
          temp_data[which(temp_data$category == "blank"),]$value <- 1 - (sum(as.numeric(temp_data[which(temp_data$category != Pat_value & temp_data$category != "blank"),]$value)) + (0.5 * as.numeric(temp_data[which(temp_data$category == Pat_value),]$value)))
          temp_data$category <- factor(temp_data$category, levels = c(Pat_value, as.character(temp_data$category)[which(temp_data$category %ni% c(Pat_value, 'blank' ))], 'blank'))
        }

        ann_text <- rbind(ann_text, data.frame(variable = v,category = temp_data[which(temp_data$category == Pat_value),]$category, value=1, alphacat= 1, LAB = temp_data[which(temp_data$category == Pat_value),]$category))

        res_data <- rbind(res_data, temp_data)


      } else { # continuous variable as median + IQR

        eval(parse(text=(paste("format <- as.character(", v, "$format)",sep=""))))
        if (format !=  "medianIQR") {
          eval(parse(text=(paste("simdat <- rnorm(18201, mean=", v, "$mean, sd=", v, "$sd)",sep=""))))
          eval(parse(text=(paste(v, "$median <- as.numeric(summary(simdat)['Median'])",sep=""))))
          eval(parse(text=(paste(v, "$IQR_low <- as.numeric(summary(simdat)['1st Qu.'])",sep=""))))
          eval(parse(text=(paste(v, "$IQR_high <- as.numeric(summary(simdat)['3rd Qu.'])",sep=""))))
          eval(parse(text=(paste(v, "$mean <- ", v, "$sd <- NULL",sep=""))))
        }
        range075 <- function(x){(((x-min(x))/(max(x)-min(x)))*0.5)+0.25 }
        range075max <- function(x){(((x-min(x))/(max( x[x!=max(x)] )-min(x)))*0.5)+0.25 }
        range075min <- function(x){(((x-min( x[x!=min(x)] ))/(max(x)-min( x[x!=min(x)] )))*0.5)+0.25 }

        eval(parse(text=(paste("medi <- range075(c(as.numeric(", v, "$median),
                               as.numeric(", v, "$IQR_low), as.numeric(", v, "$IQR_high)))[1]",sep=""))))
        eval(parse(text=(paste("low <- as.numeric(", v, "$IQR_low)",sep=""))))
        eval(parse(text=(paste("high <- as.numeric(", v, "$IQR_high)",sep=""))))

        if (as.numeric(Pat_value) > high) {
          eval(parse(text=(paste("Pat_val <- range075max(c(as.numeric(", Pat_value, "),
                                 as.numeric(", v, "$IQR_low), as.numeric(", v, "$IQR_high)))[1]",sep=""))))
        } else if (as.numeric(Pat_value) < low) {
          eval(parse(text=(paste("Pat_val <- range075min(c(as.numeric(", Pat_value, "),
                                 as.numeric(", v, "$IQR_low), as.numeric(", v, "$IQR_high)))[1]",sep=""))))
        } else {
          eval(parse(text=(paste("Pat_val <- range075(c(as.numeric(", Pat_value, "),
                                 as.numeric(", v, "$IQR_low), as.numeric(", v, "$IQR_high)))[1]",sep=""))))
        }

        for (i in c("below","above")) {
          eval(parse(text=(paste("temp_data <- rbind(temp_data, data.frame(variable='", v, "', category=i, value=ifelse(i == 'below', medi-0.25, 0.75-medi)))", sep=""))))
        }
        temp_data$category <- as.character(temp_data$category)
        eval(parse(text=(paste("newrow <- c('", v, "', category='blank', value=0)", sep=""))))
        temp_data <- insertRow(temp_data, newrow, 1)
        temp_data$value <- as.numeric(temp_data$value)
        if(is.finite(Pat_val)==TRUE  || is.finite(medi)==TRUE){}
        else{
          Pat_val <- 1
          medi <- 1
        }

        if (Pat_val < medi) {
          temp_data[which(temp_data$category == "blank"),]$value <- (1-Pat_val)+0.25#(1 - (0.5 * as.numeric(temp_data[which(temp_data$category == "below"),]$value)))+0.25
          # order tempdata
          temp_data$category <- factor(temp_data$category, levels = c(as.character(temp_data$category)[which(temp_data$category %ni% c('below', 'blank' ))], 'below', 'blank'))
          #  temp_data[which(temp_data$category != "blank"),]$value <- as.numeric(temp_data[which(temp_data$category != "blank"),]$value) + as.numeric(temp_data[which(temp_data$category == "blank"),]$value)
        } else {
          temp_data[which(temp_data$category == "blank"),]$value <- (1-Pat_val)+0.25#(1 - (sum(as.numeric(temp_data[which(temp_data$category != "above" & temp_data$category != "blank"),]$value)) + (0.5 * as.numeric(temp_data[which(temp_data$category == "above"),]$value))))+0.25
          temp_data$category <- factor(temp_data$category, levels = c('above',  'below', 'blank'))
        }

        ann_text <- rbind(ann_text, data.frame(variable = v,category = ifelse(Pat_val < medi, "below", "above"), value=1, alphacat= 1, LAB = Pat_value))

        res_data <- rbind(res_data, temp_data)

        }
    }

    return(list(res_data, ann_text))
  }

  if(vector.is.empty(PATIENT_SIMILAR_INDEXDATE)==TRUE){stop("Please Enter PATIENT_SIMILAR_INDEXDATE")}
  if(vector.is.empty(PATIENT_SIMILAR_INDEXDATE_FORMAT)==TRUE){stop("Please Enter PATIENT_SIMILAR_INDEXDATE_FORMAT")}
  #if(vector.is.empty(PATIENT_SIMILAR_ATC)==TRUE){stop("Please Enter PATIENT_SIMILAR_ATC")}
  if(vector.is.empty(PATIENT_SIMILAR_ICD)==TRUE){stop("Please Enter PATIENT_SIMILAR_ICD")}

  if(is.numeric(PATIENT_SIMILAR_BIRTH_YEAR)==FALSE){stop("PATIENT_SIMILAR_BIRTH_YEAR must be a NUMERIC Argument")}
  if(is.character(PATIENT_SIMILAR_SEX)==FALSE){stop("PATIENT_SIMILAR_SEX must be a CHARACTER Argument")}
  if(is.character(PATIENT_SIMILAR_INDEXDATE)==FALSE){stop("PATIENT_SIMILAR_INDEXDATE must be a CHARACTER Argument")}
  if(is.character(PATIENT_SIMILAR_INDEXDATE_FORMAT)==FALSE){stop("PATIENT_SIMILAR_INDEXDATE_FORMAT must be a CHARACTER Argument")}

  if(vector.is.empty(PATIENT_SIMILAR_ATC)==FALSE){
    if(is.character(PATIENT_SIMILAR_ATC)==FALSE){stop("PATIENT_SIMILAR_ATC must be a CHARACTER Argument")}
  }

  if(is.character(PATIENT_SIMILAR_ICD)==FALSE){stop("PATIENT_SIMILAR_ICD must be a CHARACTER Argument")}

  if(vector.is.empty(PATIENT_SIMILAR_ATC_COUNT)==FALSE){
    if(is.numeric(PATIENT_SIMILAR_ATC_COUNT) == FALSE){
      stop("Please Enter PATIENT_SIMILAR_ATC_COUNT must be an NUMERIC Argument")
    }}
  if(vector.is.empty(PATIENT_DIAGNOSE_TO_DRAW)==FALSE){
    if(is.character(PATIENT_DIAGNOSE_TO_DRAW) == FALSE){
      stop("Please Enter PATIENT_DIAGNOSE_TO_DRAW must be an CHARACTER Argument")
    }}

  for (i in 1:length(SELECT_COMORBIDITY)) {
    if (SELECT_COMORBIDITY[i] == "chf"){}
    else if (SELECT_COMORBIDITY[i] == "carit"){}
    else if (SELECT_COMORBIDITY[i] == "valv"){}
    else if (SELECT_COMORBIDITY[i] == "pcd"){}
    else if (SELECT_COMORBIDITY[i] == "pvd"){}
    else if (SELECT_COMORBIDITY[i] == "hypunc"){}
    else if (SELECT_COMORBIDITY[i] == "hypc"){}
    else if (SELECT_COMORBIDITY[i] == "para"){}
    else if (SELECT_COMORBIDITY[i] == "ond"){}
    else if (SELECT_COMORBIDITY[i] == "cpd"){}
    else if (SELECT_COMORBIDITY[i] == "diabunc"){}
    else if (SELECT_COMORBIDITY[i] == "diabc"){}
    else if (SELECT_COMORBIDITY[i] == "hypothy"){}
    else if (SELECT_COMORBIDITY[i] == "rf"){}
    else if (SELECT_COMORBIDITY[i] == "ld"){}
    else if (SELECT_COMORBIDITY[i] == "pud"){}
    else if (SELECT_COMORBIDITY[i] == "aids"){}
    else if (SELECT_COMORBIDITY[i] == "lymph"){}
    else if (SELECT_COMORBIDITY[i] == "metacanc"){}
    else if (SELECT_COMORBIDITY[i] == "solidtum"){}
    else if (SELECT_COMORBIDITY[i] == "rheumd"){}
    else if (SELECT_COMORBIDITY[i] == "coag"){}
    else if (SELECT_COMORBIDITY[i] == "obes"){}
    else if (SELECT_COMORBIDITY[i] == "wloss"){}
    else if (SELECT_COMORBIDITY[i] == "fed"){}
    else if (SELECT_COMORBIDITY[i] == "blane"){}
    else if (SELECT_COMORBIDITY[i] == "dane"){}
    else if (SELECT_COMORBIDITY[i] == "alcohol"){}
    else if (SELECT_COMORBIDITY[i] == "drug"){}
    else if (SELECT_COMORBIDITY[i] == "psycho"){}
    else if (SELECT_COMORBIDITY[i] == "depre"){}
    else if (SELECT_COMORBIDITY[i] == "score"){}
    else if (SELECT_COMORBIDITY[i] == "index"){}
    else if (SELECT_COMORBIDITY[i] == "wscore_ahrq"){}
    else if (SELECT_COMORBIDITY[i] == "wscore_vw"){}
    else if (SELECT_COMORBIDITY[i] == "windex_ahrq"){}
    else if (SELECT_COMORBIDITY[i] == "windex_vw"){}
    else {stop("SELECT_COMORBIDITY must be chf, carit, valv, pcd, pvd, hypunc, hypc, para, ond, cpd, diabunc, diabc, hypothy, rf, ld, pud, aids, lymph, metacanc, solidtum, rheumd, coag, obes, wloss, fed, blane, dane, alcohol, drug, psycho, depre, score, index, wscore_ahrq, wscore_vw, windex_ahrq or windex_vw")}
  }

  if(vector.is.empty(PRESCRIPTION)==TRUE){stop("Please Enter PRESCRIPTION")}
  if(vector.is.empty(PRESCRIPTION_ATC_COLNAME)==TRUE){stop("Please Enter PRESCRIPTION_ATC_COLNAME")}
  if(vector.is.empty(PRESCRIPTION_ID_COLNAME)==TRUE){stop("Please Enter PRESCRIPTION_ID_COLNAME")}
  if(vector.is.empty(DIAGNOSES)==TRUE){stop("Please Enter DIAGNOSES")}
  if(vector.is.empty(DIAGNOSES_ICD_COLNAME)==TRUE){stop("Please Enter DIAGNOSES_ICD_COLNAME")}
  if(vector.is.empty(DIAGNOSES_ID_COLNAME)==TRUE){stop("Please Enter DIAGNOSES_ID_COLNAME")}
  if(vector.is.empty(DIAGNOSES_ICD_TYPE)==TRUE){stop("Please Enter DIAGNOSES_ICD_TYPE")}
  if(vector.is.empty(INSURANTS)==TRUE){stop("Please Enter INSURANTS")}
  if(vector.is.empty(INSURANTS_ID_COLNAME)==TRUE){stop("Please Enter INSURANTS_ID_COLNAME")}
  if(vector.is.empty(INSURANTS_INDEXDATE_COLNAME)==TRUE){stop("Please Enter INSURANTS_INDEXDATE_COLNAME")}

  if(is.character(PRESCRIPTION_ATC_COLNAME)==FALSE){stop("PRESCRIPTION_ATC_COLNAME must be a CHARACTER Argument")}
  if(is.character(PRESCRIPTION_ID_COLNAME)==FALSE){stop("PRESCRIPTION_ID_COLNAME must be a CHARACTER Argument")}
  if(is.character(DIAGNOSES_ICD_COLNAME)==FALSE){stop("DIAGNOSES_ICD_COLNAME must be a CHARACTER Argument")}
  if(is.character(DIAGNOSES_ID_COLNAME)==FALSE){stop("DIAGNOSES_ID_COLNAME must be a CHARACTER Argument")}
  if(is.character(DIAGNOSES_ICD_TYPE)==FALSE){stop("DIAGNOSES_ICD_TYPE must be a CHARACTER Argument")}
  if(is.character(INSURANTS_ID_COLNAME)==FALSE){stop("INSURANTS_ID_COLNAME must be a CHARACTER Argument")}
  if(is.character(INSURANTS_INDEXDATE_COLNAME)==FALSE){stop("INSURANTS_INDEXDATE_COLNAME must be a CHARACTER Argument")}

  if(DIAGNOSES_ICD_TYPE == "icd10"){}
  else if(DIAGNOSES_ICD_TYPE == "icd9"){}
  else(stop("DIAGNOSES_ICD_TYPE must be icd10 or icd9"))



  progress(1, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

  #______________________________________________________________________________________Define Functions
  calcGowerPat <- function(datalist) {
    ID1 <- PatToMatch$id
    ID2 <- datalist$id

    df <- bind_rows(PatToMatch,datalist)

    gower.dissimilarity.mtrx <- suppressWarnings(daisy(df, metric = c("gower")))
    dissimilarity.mtrx.csv.content = as.matrix(gower.dissimilarity.mtrx)
    dissimilarity.mtrx.csv.content <- data.frame(dissimilarity.mtrx.csv.content)

    gowercount <- dissimilarity.mtrx.csv.content$X1[2]

    dfr <- data.frame(ID1,ID2,gowercount)

    return(dfr)
  }
  searchATCGower <- function(datalist,ATCsearch) {
    ATCgower <- datalist
    ID <- unique(ATCgower$ID)
    Erg <- 0
    ATCgower <- filter(ATCgower, grepl(ATCsearch, ATCgower$ATC))
    AnzahlVO <- nrow(ATCgower)
    if(nrow(ATCgower)>0){
      Erg <- 1
    }else{
      Erg <- 0
    }
    df <- data.frame(ID,AnzahlVO,Erg)
    return(df)
  }
  searchICDGower <- function(datalist) {
    ICDgower <- datalist
    id <- unique(ICDgower$id)
    Erg <- 0
    ICDgower <- filter(ICDgower, grepl(ICDsearch, ICDgower$code))
    if(nrow(ICDgower)>0){
      Erg <- 1
    }else{
      Erg <- 0
    }
    df <- data.frame(id,Erg)
    return(df)
  }
  PatDat <- function(datalist) {

    patient <- datalist
    id <- unique(patient$ID)
    sex <- unique(patient$GESCHLECHT)
    patient$INDEX <- format(patient$INDEX, "%Y")
    patient$INDEX <- as.numeric(patient$INDEX)
    age <- unique(patient$INDEX)-unique(patient$BIRTHYEAR)

    df <- data.frame(id,sex,age)
    return(df)
  }

  progress(2, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

  #______________________________________________________________________________________Define Variables
  PRESCRIPTION$ATC <- PRESCRIPTION[[PRESCRIPTION_ATC_COLNAME]]    #Bei ATC und beidem
  PRESCRIPTION$ID <- PRESCRIPTION[[PRESCRIPTION_ID_COLNAME]]

  PRESCRIPTION <- PRESCRIPTION %>%
    select(ID,ATC)

  DIAGNOSES$ICD <- DIAGNOSES[[DIAGNOSES_ICD_COLNAME]]
  DIAGNOSES$ID <- DIAGNOSES[[DIAGNOSES_ID_COLNAME]]

  DIAGNOSES <- DIAGNOSES %>%
    select(ID,ICD)

  INSURANTS$ID <- INSURANTS[[INSURANTS_ID_COLNAME]]
  if(vector.is.empty(INSURANTS_BIRTH_YEAR_COLNAME)==TRUE){INSURANTS$BIRTHYEAR <- as.numeric(9999)}else{INSURANTS$BIRTHYEAR <- INSURANTS[[INSURANTS_BIRTH_YEAR_COLNAME]]}
  if(vector.is.empty(INSURANTS_SEX_COLNAME)==TRUE){INSURANTS$GESCHLECHT <- as.numeric("1")}else{INSURANTS$GESCHLECHT <- INSURANTS[[INSURANTS_SEX_COLNAME]]}
  INSURANTS$INDEX <- INSURANTS[[INSURANTS_INDEXDATE_COLNAME]]
  INSURANTS <- INSURANTS %>%
    select(ID,BIRTHYEAR,GESCHLECHT,INDEX) %>%
    distinct()

  if(is.character(PATIENT_SIMILAR_INDEXDATE) == FALSE){
    PATIENT_SIMILAR_INDEXDATE <- as.character(PATIENT_SIMILAR_INDEXDATE)
  }
  if(is.character(PATIENT_SIMILAR_INDEXDATE_FORMAT) == FALSE){
    PATIENT_SIMILAR_INDEXDATE_FORMAT <- as.character(PATIENT_SIMILAR_INDEXDATE_FORMAT)
  }

  PATIENT_SIMILAR_INDEXDATE <- as.Date(PATIENT_SIMILAR_INDEXDATE,PATIENT_SIMILAR_INDEXDATE_FORMAT)

  #______________________________________________________________________________________Add Patient to find others for to Dataframes
  PATIENT_SIMILAR_ATC2 <- gsub("^", "",PATIENT_SIMILAR_ATC, fixed = TRUE)

  PAT_SIMILAR_ID <- PAT_SIMILAR_ID
  PAT_SIMILAR_DIAGNOSES <- data.frame(PAT_SIMILAR_ID,PATIENT_SIMILAR_ICD)
  PAT_SIMILAR_VO <- data.frame()

  for (i in 1:length(PATIENT_SIMILAR_ATC2)) {
    a <-  PATIENT_SIMILAR_ATC_COUNT[i]
    for (j in 1:a){
      PAT_SIMILAR_VO_ub <- data.frame(PAT_SIMILAR_ID,PATIENT_SIMILAR_ATC2[i])
      PAT_SIMILAR_VO <- bind_rows(PAT_SIMILAR_VO_ub, PAT_SIMILAR_VO)
    }
  }

  PAT_SIMILAR_PAT <- data.frame(PAT_SIMILAR_ID, PATIENT_SIMILAR_SEX, PATIENT_SIMILAR_BIRTH_YEAR, PATIENT_SIMILAR_INDEXDATE)

  if(is.character(PAT_SIMILAR_DIAGNOSES$PATIENT_SIMILAR_ICD) == FALSE){
    PAT_SIMILAR_DIAGNOSES$PATIENT_SIMILAR_ICD <- as.character(PAT_SIMILAR_DIAGNOSES$PATIENT_SIMILAR_ICD)
  }
  if(is.character(PAT_SIMILAR_VO$PATIENT_SIMILAR_ATC) == FALSE){
    PAT_SIMILAR_VO$PATIENT_SIMILAR_ATC2.i. <- as.character(PAT_SIMILAR_VO$PATIENT_SIMILAR_ATC2.i.)
  }
  if(is.numeric(PAT_SIMILAR_PAT$PATIENT_SIMILAR_SEX) == FALSE){
    PAT_SIMILAR_PAT$PATIENT_SIMILAR_SEX <- as.numeric(as.character(PAT_SIMILAR_PAT$PATIENT_SIMILAR_SEX))
  }
  if(is.numeric(PAT_SIMILAR_PAT$PATIENT_SIMILAR_BIRTH_YEAR) == FALSE){
    PAT_SIMILAR_PAT$PATIENT_SIMILAR_BIRTH_YEAR <- as.numeric(PAT_SIMILAR_PAT$PATIENT_SIMILAR_BIRTH_YEAR)
  }

  PAT_SIMILAR_DIAGNOSES <- PAT_SIMILAR_DIAGNOSES %>%
    rename(ID = PAT_SIMILAR_ID, ICD = PATIENT_SIMILAR_ICD)

  PAT_SIMILAR_VO <- PAT_SIMILAR_VO %>%
    rename(ID = PAT_SIMILAR_ID, ATC = PATIENT_SIMILAR_ATC2.i.)

  PAT_SIMILAR_PAT <- PAT_SIMILAR_PAT %>%
    rename(ID = PAT_SIMILAR_ID, GESCHLECHT = PATIENT_SIMILAR_SEX, BIRTHYEAR = PATIENT_SIMILAR_BIRTH_YEAR, INDEX = PATIENT_SIMILAR_INDEXDATE)
  DIAGNOSES <- bind_rows(DIAGNOSES, PAT_SIMILAR_DIAGNOSES)
  PRESCRIPTION <- bind_rows(PRESCRIPTION, PAT_SIMILAR_VO)
  INSURANTS <- bind_rows(INSURANTS,PAT_SIMILAR_PAT)

  DIAGNOSES <- DIAGNOSES %>%
    rename(id = ID, code=ICD)

  progress(3, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

  #______________________________________________________________________________________Calculate Commorbidity-Matrix

  COMORBIDITY_MATRIX <- comorbidity(x = DIAGNOSES, id = "id", code = "code", score = "elixhauser", icd = DIAGNOSES_ICD_TYPE, assign0 = FALSE)

  COMORBIDITY_MATRIX <- COMORBIDITY_MATRIX %>%
    select(id,SELECT_COMORBIDITY)

  for (i in 1:length(SELECT_COMORBIDITY)) {
    comorb <- SELECT_COMORBIDITY[i]
    COMORBIDITY_MATRIX[,comorb] <- as.factor(COMORBIDITY_MATRIX[,comorb])
  }

  progress(4, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

  if(is.character(PATIENT_SIMILAR_ATC) == FALSE){
    PATIENT_SIMILAR_ATC <- as.character(PATIENT_SIMILAR_ATC)
  }
  datalist <- split(PRESCRIPTION,PRESCRIPTION$ID)
  if (vector.is.empty(PATIENT_SIMILAR_ATC)==FALSE){
    for (i in 1:length(PATIENT_SIMILAR_ATC)) {
      ATCsearch <- PATIENT_SIMILAR_ATC[i]
      datalist2 <- map(datalist,searchATCGower,ATCsearch)
      gower1ATC <- rbindlist(datalist2)
      gower1ATC <- gower1ATC %>%
        rename(id = ID)
      COMORBIDITY_MATRIX <- merge(COMORBIDITY_MATRIX,gower1ATC, by = "id")
      namenspalten <- names(COMORBIDITY_MATRIX)
      namenspalten <- namenspalten[-length(namenspalten)]
      namenspalten <- namenspalten[-length(namenspalten)]
      namenspalten <- append(namenspalten, paste("CountVO",ATCsearch,sep = ""))
      namenspalten <- append(namenspalten, ATCsearch)
      colnames(COMORBIDITY_MATRIX) <- namenspalten
      COMORBIDITY_MATRIX[,paste("CountVO",ATCsearch,sep = "")] <- as.numeric(COMORBIDITY_MATRIX[,paste("CountVO",ATCsearch,sep = "")])
      COMORBIDITY_MATRIX[,ATCsearch] <- as.factor(COMORBIDITY_MATRIX[,ATCsearch])
    }}
  if (vector.is.empty(PATIENT_DIAGNOSE_TO_DRAW)==FALSE){
    datalist <- split(DIAGNOSES,DIAGNOSES$id)
    for (i in 1:length(PATIENT_DIAGNOSE_TO_DRAW)) {
      ICDsearch <- PATIENT_DIAGNOSE_TO_DRAW[i]
      datalist2 <- map(datalist,searchICDGower)
      gower1ICD <- rbindlist(datalist2)
      COMORBIDITY_MATRIX <- merge(COMORBIDITY_MATRIX,gower1ICD, by = "id")
      namenspalten <- names(COMORBIDITY_MATRIX)
      namenspalten <- namenspalten[-length(namenspalten)]
      namenspalten <- append(namenspalten, ICDsearch)
      colnames(COMORBIDITY_MATRIX) <- namenspalten
      COMORBIDITY_MATRIX[,ICDsearch] <- as.factor(COMORBIDITY_MATRIX[,ICDsearch])
    }}
  datalist <- split(INSURANTS,INSURANTS$ID)
  datalist <- map(datalist,PatDat)
  patdaten <- rbindlist(datalist)
  patdaten <- patdaten %>%
    distinct()

  COMORBIDITY_MATRIX <- merge(COMORBIDITY_MATRIX,patdaten, by ="id")
  COMORBIDITY_MATRIX$sex <- as.character(COMORBIDITY_MATRIX$sex)

  zero <- COMORBIDITY_MATRIX %>%
    filter(COMORBIDITY_MATRIX$sex == INSURANTS_SEX_MALE)
  one <- COMORBIDITY_MATRIX %>%
    filter(COMORBIDITY_MATRIX$sex == INSURANTS_SEX_FEMALE)

  if(nrow(zero)!=0){
    zero$sex <- 0}
  if(nrow(one)!=0){
    one$sex <- 1}

  if(nrow(one)!=0 && nrow(zero)!=0){
    COMORBIDITY_MATRIX <- bind_rows(zero,one)
  }else {
    if(nrow(zero)!=0){
      COMORBIDITY_MATRIX <- zero}
    if(nrow(one)!=0){
      COMORBIDITY_MATRIX <- one}
  }

  COMORBIDITY_MATRIX$sex <- as.factor(COMORBIDITY_MATRIX$sex)

  progress(5, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
  #______________________________________________________________________________________Analysis
  names(COMORBIDITY_MATRIX) <- gsub("[[:punct:]]", "", names(COMORBIDITY_MATRIX))

  if(PATIENT_SIMILAR_ATC == "ZZZ" & SELECT_COMORBIDITY == "score" & PATIENT_SIMILAR_ICD == "z"){
    COMORBIDITY_MATRIX <- COMORBIDITY_MATRIX[ , -which(names(COMORBIDITY_MATRIX) %in% c("ZZZ","CountVOZZZ"))]
  }else{
    if(PATIENT_SIMILAR_ATC == "ZZZ"){
      COMORBIDITY_MATRIX <- COMORBIDITY_MATRIX[ , -which(names(COMORBIDITY_MATRIX) %in% c("ZZZ","CountVOZZZ"))]
    }
    if(SELECT_COMORBIDITY == "score"){
      COMORBIDITY_MATRIX <- COMORBIDITY_MATRIX[ , -which(names(COMORBIDITY_MATRIX) %in% c("score"))]
    }}


  Patient <- COMORBIDITY_MATRIX %>%
    filter(COMORBIDITY_MATRIX$id == 999999999999)

  COMORBIDITY_MATRIX <- COMORBIDITY_MATRIX %>%
    filter(COMORBIDITY_MATRIX$id != 999999999999)

  counter <- COMORBIDITY_MATRIX[0,]
  save <- list()
  for (i in 1:length(counter)) {
    intermediate <- COMORBIDITY_MATRIX[,i]
    dfname <- paste("df",i, sep = "")

    if(is.numeric(intermediate)==TRUE){
      MEDIAN  <- median(intermediate)
      IQR_LOW <- quantile(intermediate,probs = c(0.25))
      IQR_HIGH <- quantile(intermediate,probs = c(0.75))

      save[[i]] <- data.frame(type="numeric", # ARISTOTLE
                              format="medianIQR", # oder meansd
                              median=MEDIAN,
                              IQR_low=IQR_LOW,
                              IQR_high=IQR_HIGH)
    }

    if(is.factor(intermediate)==TRUE){

      intermediate <- table(intermediate)

      YES <- intermediate[names(intermediate)==1]
      NO <- intermediate[names(intermediate)==0]


      YEES <- as.integer(YES)
      NOO <- as.integer(NO)

      if(length(NOO)==0){
        NOO <- 0
      }
      if(length(YEES)==0){
        YEES <- 0
      }

      GES <- YEES+NOO


      save[[i]] <- data.frame(type="categorical",
                              format="percent",
                              y=(YEES/GES),
                              n=(NOO/GES),
                              N=GES)
    }

  }

  counter <- Patient[0,]
  for (i in 1:length(counter)) {
    if(is.factor(Patient[,i]) == TRUE){

      if(Patient[,i]==1){
        Patient[,i] <- "y"
      }
      if(Patient[,i]==0){
        Patient[,i] <- "n"
      }
    }
  }
  progress(6, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

  if(Patient$sex == "n"){
    Patient$sex <- "m"
  }
  if(Patient$sex == "y"){
    Patient$sex <- "w"
  }

  counter <- length(save)-1

  save[[counter]]$w <- save[[counter]]$y
  save[[counter]]$m <- save[[counter]]$n
  save[[counter]]$n <- NULL
  save[[counter]]$y <- NULL


  counter <- COMORBIDITY_MATRIX[0,]
  namen <- names(COMORBIDITY_MATRIX)

  for (i in 1:length(counter)) {
    name <- namen[i]
    assign(name,save[[i]])
  }

  analyse <- names(COMORBIDITY_MATRIX)
  Patient <- Patient %>%
    select(analyse)

  sex[,6] <- sex[,3]
  sex[,3] <- sex[,4]
  sex[,4] <- sex[,5]
  sex[,5] <- sex[,6]
  sex[,6] <- NULL

  names(sex) <- c("type","format","w","m","N")
  progress(7, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)


  for (v in analyse) {
    eval(parse(text=(paste(v, "_dat <- make_scale_data(Pat=Patient2, vars=c('", v, "'), studies=NULL)[[1]]",sep=""))))
    eval(parse(text=(paste(v, "_dat$alphacat <- 1",sep=""))))
    eval(parse(text=(paste(v, "_dat$alphacat <- ifelse(", v, "_dat$category=='blank',0,1)",sep=""))))
    eval(parse(text=(paste(v, "_ann_text <- make_scale_data(Pat=Patient2, vars=c('", v, "'), studies=NULL)[[2]]",sep=""))))
  }
  barwidth <- 0.5
  progress(8, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
  if(vector.is.empty(INSURANTS_BIRTH_YEAR_COLNAME)== FALSE && vector.is.empty(INSURANTS_SEX_COLNAME)==FALSE){
    plotname <- c("age")
    for (i in 0:(length(analyse)-4)) {
      plotname <- append(plotname,analyse[i+2])
    }
    plotname <- append(plotname,"sex")
    plotname <- sort(plotname)
    if(vector.is.empty(Change_Name_Plot) == FALSE){plotname <- Change_Name_Plot}
    plotcode <-  paste0('ggplot(age_dat, aes(fill=category, y=value, x=variable, alpha=factor(alphacat))) + #order=as.numeric(category)
                        geom_bar(stat="identity", width=barwidth) + scale_y_continuous(name="", breaks=c(0,2))+#coord_flip() +
                        scale_x_discrete(name="", labels=plotname)+','scale_alpha_manual(values = c("0"=0, "1"=1), guide="none") +
                        geom_hline(yintercept = 1, color="red", size=2, linetype="dashed") +
                        geom_label(data = age_ann_text,aes(label = LAB), color="red", size=6.5) +
                        geom_bar(data=sex_dat, stat="identity", width=barwidth) +
                        geom_label(data = sex_ann_text,aes(label = LAB), color="red", size=6.5) +', sep="")

    for (i in 0:(length(analyse)-4)) {
      a <- paste('geom_bar(data=',analyse[i+2],'_dat, stat="identity", width=barwidth) +
                 geom_label(data = ',analyse[i+2],'_ann_text,aes(label = LAB), color="red", size=6.5) +', sep="")
      plotcode <- paste0(plotcode,a,sep = "")
    }


    plotcode <- paste0(plotcode,'scale_fill_manual(values=c("#003366", "#6699CC", "#999999",
                       "#003366", "#6699CC",
                       "#6699CC","#003366")) + theme_minimal() +
                       theme(axis.line = element_line(size = 1.2, colour = "black", linetype = "solid"),
                       axis.ticks.x = element_line(size = 1.2),
                       axis.ticks.y = element_blank(),
                       axis.ticks.length = unit(.5, "cm"),
                       axis.text.x = element_text(colour="black", size=18, angle=90, hjust=0.95,vjust=0.5),
                       axis.text.y = element_blank(),
                       axis.title.y =  element_text(colour="black", size=18),#
                       plot.title = element_text(hjust = -0.25, size=18),
                       plot.margin=unit(c(0.05,0,0.05,0), "cm"),
                       legend.position = "none")',sep="")

    p <- eval(parse(text = plotcode))


  } #Age and SEX are in the Dataset
  if(vector.is.empty(INSURANTS_BIRTH_YEAR_COLNAME)== FALSE && vector.is.empty(INSURANTS_SEX_COLNAME)==TRUE){
    plotname <- c("age")
    for (i in 0:(length(analyse)-4)) {
      plotname <- append(plotname,analyse[i+2])
    }
    plotname <- sort(plotname)
    if(vector.is.empty(Change_Name_Plot) == FALSE){plotname <- Change_Name_Plot}
    plotcode <-  paste0('ggplot(age_dat, aes(fill=category, y=value, x=variable, alpha=factor(alphacat))) + #order=as.numeric(category)
                        geom_bar(stat="identity", width=barwidth) + scale_y_continuous(name="", breaks=c(0,2))+#coord_flip() +
                        scale_x_discrete(name="", labels=plotname)+','scale_alpha_manual(values = c("0"=0, "1"=1), guide="none") +
                        geom_hline(yintercept = 1, color="red", size=2, linetype="dashed") +
                        geom_label(data = age_ann_text,aes(label = LAB), color="red", size=6.5) +', sep="")

    for (i in 0:(length(analyse)-4)){
      a <- paste('geom_bar(data=',analyse[i+2],'_dat, stat="identity", width=barwidth) +
                 geom_label(data = ',analyse[i+2],'_ann_text,aes(label = LAB), color="red", size=6.5) +', sep="")
      plotcode <- paste0(plotcode,a,sep = "")
    }


    plotcode <- paste0(plotcode,'scale_fill_manual(values=c("#003366", "#6699CC", "#999999",
                       "#003366", "#6699CC",
                       "#6699CC","#003366")) + theme_minimal() +
                       theme(axis.line = element_line(size = 1.2, colour = "black", linetype = "solid"),
                       axis.ticks.x = element_line(size = 1.2),
                       axis.ticks.y = element_blank(),
                       axis.ticks.length = unit(.5, "cm"),
                       axis.text.x = element_text(colour="black", size=18, angle=90, hjust=0.95,vjust=0.5),
                       axis.text.y = element_blank(),
                       axis.title.y =  element_text(colour="black", size=18),#
                       plot.title = element_text(hjust = -0.25, size=18),
                       plot.margin=unit(c(0.05,0,0.05,0), "cm"),
                       legend.position = "none")',sep="")

    p <- eval(parse(text = plotcode))
  } #AGE is in Dataset
  if(vector.is.empty(INSURANTS_BIRTH_YEAR_COLNAME)== TRUE && vector.is.empty(INSURANTS_SEX_COLNAME)==FALSE){
    plotname <- c("sex")
    for (i in 0:(length(analyse)-4)) {
      plotname <- append(plotname,analyse[i+2])
    }
    plotname <- sort(plotname)
    if(vector.is.empty(Change_Name_Plot) == FALSE){plotname <- Change_Name_Plot}
    plotcode <-  paste0('ggplot(sex_dat, aes(fill=category, y=value, x=variable, alpha=factor(alphacat))) + #order=as.numeric(category)
                        geom_bar(stat="identity", width=barwidth) + scale_y_continuous(name="", breaks=c(0,2))+#coord_flip() +
                        scale_x_discrete(name="", labels=plotname)+','scale_alpha_manual(values = c("0"=0, "1"=1), guide="none") +
                        geom_hline(yintercept = 1, color="red", size=2, linetype="dashed") +
                        geom_label(data = sex_ann_text,aes(label = LAB), color="red", size=6.5) +', sep="")

    for (i in 0:(length(analyse)-4)){

      a <- paste('geom_bar(data=',analyse[i+2],'_dat, stat="identity", width=barwidth) +
                 geom_label(data = ',analyse[i+2],'_ann_text,aes(label = LAB), color="red", size=6.5) +', sep="")
      plotcode <- paste0(plotcode,a,sep = "")
    }


    plotcode <- paste0(plotcode,'scale_fill_manual(values=c("#003366", "#6699CC", "#999999",
                       "#003366", "#6699CC",
                       "#6699CC","#003366")) + theme_minimal() +
                       theme(axis.line = element_line(size = 1.2, colour = "black", linetype = "solid"),
                       axis.ticks.x = element_line(size = 1.2),
                       axis.ticks.y = element_blank(),
                       axis.ticks.length = unit(.5, "cm"),
                       axis.text.x = element_text(colour="black", size=18, angle=90, hjust=0.95,vjust=0.5),
                       axis.text.y = element_blank(),
                       axis.title.y =  element_text(colour="black", size=18),#
                       plot.title = element_text(hjust = -0.25, size=18),
                       plot.margin=unit(c(0.05,0,0.05,0), "cm"),
                       legend.position = "none")',sep="")

    p <- eval(parse(text = plotcode))} #SEx is in Dataset
  if(vector.is.empty(INSURANTS_BIRTH_YEAR_COLNAME)== TRUE && vector.is.empty(INSURANTS_SEX_COLNAME)==TRUE){
    plotname <- c()
    for (i in 0:(length(analyse)-4)) {
      plotname <- append(plotname,analyse[i+2])
    }
    plotname <- sort(plotname)
    startname <- paste(plotname[1],"_dat",sep = "")
    starttext <- paste(plotname[1],"_ann_text",sep = "")
    if(vector.is.empty(Change_Name_Plot) == FALSE){plotname <- Change_Name_Plot}
    plotcode <-  paste0('ggplot(',startname,', aes(fill=category, y=value, x=variable, alpha=factor(alphacat))) + #order=as.numeric(category)
                        geom_bar(stat="identity", width=barwidth) + scale_y_continuous(name="", breaks=c(0,2))+#coord_flip() +
                        scale_x_discrete(name="", labels=plotname)+','scale_alpha_manual(values = c("0"=0, "1"=1), guide="none") +
                        geom_hline(yintercept = 1, color="red", size=2, linetype="dashed") +
                        geom_label(data =',starttext,',aes(label = LAB), color="red", size=6.5) +', sep="")

    for (i in 0:(length(analyse)-4)){
      a <- paste('geom_bar(data=',analyse[i+2],'_dat, stat="identity", width=barwidth) +
                 geom_label(data = ',analyse[i+2],'_ann_text,aes(label = LAB), color="red", size=6.5) +', sep="")
      plotcode <- paste0(plotcode,a,sep = "")
    }


    plotcode <- paste0(plotcode,'scale_fill_manual(values=c("#003366", "#6699CC", "#999999",
                       "#003366", "#6699CC",
                       "#6699CC","#003366")) + theme_minimal() +
                       theme(axis.line = element_line(size = 1.2, colour = "black", linetype = "solid"),
                       axis.ticks.x = element_line(size = 1.2),
                       axis.ticks.y = element_blank(),
                       axis.ticks.length = unit(.5, "cm"),
                       axis.text.x = element_text(colour="black", size=18, angle=90, hjust=0.95,vjust=0.5),
                       axis.text.y = element_blank(),
                       axis.title.y =  element_text(colour="black", size=18),#
                       plot.title = element_text(hjust = -0.25, size=18),
                       plot.margin=unit(c(0.05,0,0.05,0), "cm"),
                       legend.position = "none")',sep="")

    p <- eval(parse(text = plotcode)) #SEx is in Dataset} #Age and Sex are not in the dataset
  }
  progress(9, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
  options(warn=0)
  progress(10, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
  return(p)
  }

