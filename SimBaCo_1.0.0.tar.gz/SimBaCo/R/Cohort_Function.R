#' Cohort Builder Function
#'
#' Build Study Cohort from Claims Data according to the criteria you set!
#'
#' @import cluster
#' @import comorbidity
#' @import varhandle
#' @import dplyr
#' @import formattable
#' @import ggplot2
#' @import feather
#' @import purrr
#' @import data.table
#' @import shiny
#' @import rlist
#' @import RColorBrewer
#' @import gridExtra
#' @import forcats
#' @import furrr
#' @import foreach
#' @import doParallel
#' @import stringr
#' @import parallel
#' @import snow
#' @import survival
#' @import survminer
#' @import pROC
#' @import factoextra
#' @import readr
#' @import Rtsne
#' @import iterators
#' @import UBL
#' @import svMisc
#' @import lubridate
#'
#'
#' @param STUDYDESIGN Studydesign, can be set to "NewUser" or "PraevalentUser"
#' @param INDEXTYPE Indextype, can be set to "ATC" or "ICD"
#' @param STARTDATE STARTDATE, first date in the dataset or start date of the dataset
#' @param STARTDATE_Format STARTDATE_Format, date format of the field start date
#' @param PRELIMINARY_TIME_SPAN PRELIMINARY_TIME_SPAN, the minimum timespan between start date of the dataset and the index date.
#' @param INDEXDATE_PRAEVALENT INDEXDATE_PRAEVALENT, index date for all patients in the mode "PraevalentUser"
#' @param INDEXDATE_PRAEVALENT_FORMAT INDEXDATE_PRAEVALENT_FORMAT, date format of the field INDEXDATE_PRAEVALENT
#' @param ATC_INPUT ATC_INPUT, enter the ATC codes to filter for (grepl allowed)
#' @param PRESCRIPTION PRESCRIPTION, name of the data frame containing the prescriptions.
#' @param PRESCRIPTION_ATC_COLNAME PRESCRIPTION_ATC_COLNAME, name of the column in the data frame PRESCRIPTION containing the ATC codes
#' @param PRESCRIPTION_ID_COLNAME PRESCRIPTION_ID_COLNAME, name of the column in the data frame PRESCRIPTION containing the patient IDs
#' @param PRESCRIPTION_DATE_COLNAME PRESCRIPTION_DATE_COLNAME, name of the column in the data frame PRESCRIPTION containing the PRESCRIPTION dates
#' @param ICD_INPUT ICD_INPUT, enter the ICD-Codes to filter for (grepl allowed)
#' @param DIAGNOSES DIAGNOSES, name of the data frame containing the diagnoses.
#' @param DIAGNOSES_ICD_COLNAME DIAGNOSES_ICD_COLNAME, name of the column in the data frame DIAGNOSES containing the ICD codes of the diagnoses
#' @param DIAGNOSES_ID_COLNAME DIAGNOSES_ID_COLNAME, name of the column in the data frame DIAGNOSES containing the patient IDs
#' @param DIAGNOSES_DATE_COLNAME DIAGNOSES_DATE_COLNAME, name of the column in the data frame DIAGNOSES containing the diagnosis dates
#' @param INSURANTS INSURANTS, name of the data frame containing the patient data
#' @param INSURANTS_ID_COLNAME INSURANTS_ID_COLNAME, name of the column in the data frame INSURANTS containing the patient IDs
#' @param INSURANTS_BIRTH_YEAR_COLNAME INSURANTS_BIRTH_YEAR_COLNAME, name of the column in the data frame INSURANTS containing the year of birth of the patient
#' @param EXCLUSION_ATC EXCLUSION_ATC, enter ATC codes which are not allowed to be prescribed in the PRELIMINARY_TIME_SPAN
#' @param EXCLUSION_ICD EXCLUSION_ICD, enter ICD codes which are not allowed to be diagnosed in the PRELIMINARY_TIME_SPAN
#' @param MIN_INCLUSION_AGE MIN_INCLUSION_AGE, minimum age in years to add a patient to the cohort
#' @param MIN_NUM_PRESCRIPTION MIN_NUM_PRESCRIPTION, minimum number of prescriptions in each of the ATC codes to add a patient to the cohort
#'
#'
#' @return Dataframe consisting of ID's matching the criteria and there Indexdate
#'
#' @author Lucas Wirbka, \email{Lucas.Wirbka@@med.uni-heidelberg.de}
#'
#' @examples
#'
#' d <- buildcohort(STUDYDESIGN = "PraevalentUser",
#'                  INDEXTYPE = "ATC",
#'                  STARTDATE = "20110101",
#'                  STARTDATE_Format = "%Y%m%d",
#'                  PRELIMINARY_TIME_SPAN = 365,
#'                  INDEXDATE_PRAEVALENT = "20130101",
#'                  INDEXDATE_PRAEVALENT_FORMAT = "%Y%m%d",
#'                  ATC_INPUT = ATC_Eingabe,
#'                  PRESCRIPTION = PRESCRIPTION,
#'                  PRESCRIPTION_ATC_COLNAME = "ATC",
#'                  PRESCRIPTION_ID_COLNAME = "Versid",
#'                  PRESCRIPTION_DATE_COLNAME = "VerordnungsDATE",
#'                  ICD_INPUT = ICD_Eingabe,
#'                  DIAGNOSES = DIAGNOSES,
#'                  DIAGNOSES_ICD_COLNAME = "ICD",
#'                  DIAGNOSES_ID_COLNAME = "Versid.x",
#'                  DIAGNOSES_DATE_COLNAME = "Beginn",
#'                  INSURANTS = VERS,
#'                  INSURANTS_ID_COLNAME = "Versid",
#'                  INSURANTS_BIRTH_YEAR_COLNAME = "Geburtsjahr",
#'                  EXCLUSION_ATC = c("^P02AE04"),
#'                  EXCLUSION_ICD = AusschlussICD,
#'                  MIN_INCLUSION_AGE = 30,
#'                  MIN_NUM_PRESCRIPTION = 4)
#'
#'
#'
#' @export
buildcohort <- function(STUDYDESIGN=c(),INDEXTYPE=c(),STARTDATE=c(),PRELIMINARY_TIME_SPAN=c(365),ATC_INPUT=c(),ICD_INPUT=c(),PRESCRIPTION=c(),PRESCRIPTION_ATC_COLNAME=c(),PRESCRIPTION_DATE_COLNAME=c(),PRESCRIPTION_ID_COLNAME=c(),DIAGNOSES=c(),DIAGNOSES_ICD_COLNAME=c(),DIAGNOSES_ID_COLNAME=c(),DIAGNOSES_DATE_COLNAME=c(),EXCLUSION_ATC=c(),EXCLUSION_ICD=c(),INSURANTS_BIRTH_YEAR_COLNAME=c(),INSURANTS=c(),INSURANTS_ID_COLNAME=c(),MIN_INCLUSION_AGE=c(),MIN_NUM_PRESCRIPTION=c(),INDEXDATE_PRAEVALENT=c(),STARTDATE_Format=c(),INDEXDATE_PRAEVALENT_FORMAT=c()){
  options(warn=-1)
  progress(0, max.value = 10, progress.bar = TRUE, char = "|",init = TRUE, console = TRUE, gui = TRUE)
  #______________________________________________________________________________________Define Functions

  vector.is.empty <- function(x) return(length(x) ==0)
  getindexDATEATC <- function(datalist){
    ID <- datalist$ID[1]
    DATEIndex <- min(datalist$DATE)
    indexDATE <- data.frame(ID,DATEIndex)
    return(indexDATE)
  }
  getindexDATEICD <- function(datalist){
    ID <- datalist$ID[1]
    DATEIndex <- min(datalist$DATE)
    indexDATE <- data.frame(ID,DATEIndex)
    return(indexDATE)
  }
  firstdateDIAG <- function(datalist){
    datalist$ErstdiagnoseDIAG <- min(datalist$DATE)
    return(datalist)
  }
  countmedi <- function(datalist,ATC_INPUT){

    ID <- unique(datalist$ID)
    ATC <- NA
    COUNT <- 0

    df <- data.frame()

    for (i in 1:length(ATC_INPUT)) {
      calcframe <- datalist
      ATC <- ATC_Eingabe[i]

      calcframe <- calcframe %>%
        filter(grepl(paste(ATC_INPUT, collapse="|"), calcframe$ATC)) #Grepl Filter der PRESCRIPTION

      COUNT <- nrow(calcframe)
      safeframe <- data.frame(ID,ATC,COUNT)
      df <- bind_rows(df,safeframe)
    }

    return(df)
  }
  progress(1, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
  #______________________________________________________________________________________Check if Variables are Correct

  if(vector.is.empty(STUDYDESIGN)==TRUE){stop("Please Enter STUDYDESIGN")}
  if(vector.is.empty(INDEXTYPE)==TRUE){stop("Please Enter INDEXTYPE")}
  if(vector.is.empty(STARTDATE)==TRUE){stop("Please Enter STARTDATE")}
  if(vector.is.empty(STARTDATE_Format)==TRUE){stop("Please Enter STARTDATE_Format")}

  if(is.character(STUDYDESIGN)==FALSE){stop("Please Change Variable Type of STUDYDESIGN to Character")}
  if(is.character(INDEXTYPE)==FALSE){stop("Please Change Variable Type of INDEXTYPE to Character")}
  if(is.character(STARTDATE)==FALSE){stop("Please Change Variable Type of STARTDATE to Character")}
  if(is.character(STARTDATE_Format)==FALSE){stop("Please Change Variable Type of STARTDATE_Format to Character")}

  if(STUDYDESIGN == "NewUser"){}
  else if (STUDYDESIGN == "PraevalentUser"){}
  else{stop("Please select NewUser or PraevalentUser for STUDYDESIGN")}

  if(INDEXTYPE == "ATC"){}
  else if(INDEXTYPE == "ICD"){}
  else{stop("Please select ATC or ICD for STUDYDESIGN")}

  if(STUDYDESIGN == "PraevalentUser"){

    if(vector.is.empty(INDEXDATE_PRAEVALENT)==TRUE){stop("Please Enter INDEXDATE_PRAEVALENT")}
    if(vector.is.empty(INDEXDATE_PRAEVALENT_FORMAT)==TRUE){stop("Please Enter INDEXDATE_PRAEVALENT_FORMAT")}

    if(is.character(INDEXDATE_PRAEVALENT)==FALSE){stop("Please Change Variable Type of INDEXDATE_PRAEVALENT to Character")}
    if(is.character(INDEXDATE_PRAEVALENT_FORMAT)==FALSE){stop("Please Change Variable Type of INDEXDATE_PRAEVALENT_FORMAT to Character")}
  }

  if(vector.is.empty(EXCLUSION_ATC)==FALSE){
    if(is.character(EXCLUSION_ATC)==FALSE){stop("Please Change Variable Type of EXCLUSION_ATC to Character")}

    PRESCRIPTION$ATC <- PRESCRIPTION[[PRESCRIPTION_ATC_COLNAME]]
    PRESCRIPTION$ID <- PRESCRIPTION[[PRESCRIPTION_ID_COLNAME]]
    PRESCRIPTION$DATE <- PRESCRIPTION[[PRESCRIPTION_DATE_COLNAME]]

    PRESCRIPTION <- PRESCRIPTION %>%
      select(ID,ATC,DATE)

  }
  if(vector.is.empty(EXCLUSION_ICD)==FALSE){
    if(is.character(EXCLUSION_ICD)==FALSE){stop("Please Change Variable Type of EXCLUSION_ICD to Character")}
    DIAGNOSES$ICD <- DIAGNOSES[[DIAGNOSES_ICD_COLNAME]]
    DIAGNOSES$ID <- DIAGNOSES[[DIAGNOSES_ID_COLNAME]]
    DIAGNOSES$DATE <- DIAGNOSES[[DIAGNOSES_DATE_COLNAME]]

    DIAGNOSES <- DIAGNOSES %>%
      select(ID,ICD,DATE)
  }
  if(vector.is.empty(MIN_NUM_PRESCRIPTION)==FALSE){
    if(INDEXTYPE != "ATC" || vector.is.empty(ATC_INPUT)==TRUE){stop("You need to select INDEXTYPE = ATC and set an ATC to search in the field ATC_INPUT to do this analysis!")}
    if(is.numeric(MIN_NUM_PRESCRIPTION)==FALSE){stop("Please Change Variable Type of MIN_NUM_PRESCRIPTION to Numeric")}
    PRESCRIPTION$ATC <- PRESCRIPTION[[PRESCRIPTION_ATC_COLNAME]]
    PRESCRIPTION$ID <- PRESCRIPTION[[PRESCRIPTION_ID_COLNAME]]
    PRESCRIPTION$DATE <- PRESCRIPTION[[PRESCRIPTION_DATE_COLNAME]]

    PRESCRIPTION <- PRESCRIPTION %>%
      select(ID,ATC,DATE)
  }
  if(vector.is.empty(MIN_INCLUSION_AGE)==FALSE){
    if(is.numeric(MIN_INCLUSION_AGE)==FALSE){stop("Please Change Variable Type of MIN_INCLUSION_AGE to Numeric")}
    if(vector.is.empty(INSURANTS)==TRUE){stop("Please Enter Dataframe for INSURANTS")}
    if(vector.is.empty(INSURANTS)==FALSE){
      if(vector.is.empty(INSURANTS_ID_COLNAME)==TRUE){stop("Please Enter INSURANTS_ID_COLNAME or delete INSURANTS")}
      if(vector.is.empty(INSURANTS_BIRTH_YEAR_COLNAME)==TRUE){stop("Please Enter INSURANTS_BIRTH_YEAR_COLNAME or delete INSURANTS")}

      if(is.character(INSURANTS_ID_COLNAME)==FALSE){stop("Please Change Variable Type of INSURANTS_ID_COLNAME to Character")}
      if(is.character(INSURANTS_BIRTH_YEAR_COLNAME)==FALSE){stop("Please Change Variable Type of INSURANTS_BIRTH_YEAR_COLNAME to Character")}

      INSURANTS$ID <- INSURANTS[[INSURANTS_ID_COLNAME]]
      INSURANTS$BIRTHYEAR <- INSURANTS[[INSURANTS_BIRTH_YEAR_COLNAME]]

      INSURANTS <- INSURANTS %>%
        select(ID,BIRTHYEAR)

    }
  }
  if(vector.is.empty(PRELIMINARY_TIME_SPAN)==FALSE){
    if(is.numeric(PRELIMINARY_TIME_SPAN)==FALSE){stop("Please Change Variable Type of PRELIMINARY_TIME_SPAN to Numeric")}
  }

  if (vector.is.empty(ATC_INPUT)==FALSE && vector.is.empty(ICD_INPUT)==FALSE) {
    if (is.character(ATC_INPUT)==FALSE || is.character(ICD_INPUT)==FALSE){stop("Please Change Variable Type of ATC_INPUT AND/OR ICD_INPUT to Character")}

    if (vector.is.empty(PRESCRIPTION)==TRUE) {stop("Please Enter Name of Dataframe at PRESCRIPTION")}
    if (vector.is.empty(PRESCRIPTION_ID_COLNAME)==TRUE) {stop("Please Enter PRESCRIPTION_ID_COLNAME")}
    if (vector.is.empty(PRESCRIPTION_ATC_COLNAME)==TRUE) {stop("Please Enter PRESCRIPTION_ATC_COLNAME")}
    if (vector.is.empty(PRESCRIPTION_DATE_COLNAME)==TRUE) {stop("Please Enter PRESCRIPTION_DATE_COLNAME")}

    if (vector.is.empty(DIAGNOSES)==TRUE) {stop("Please Enter Name of Dataframe at DIAGNOSES")}
    if (vector.is.empty(DIAGNOSES_ID_COLNAME)==TRUE) {stop("Please Enter DIAGNOSES_ID_COLNAME")}
    if (vector.is.empty(DIAGNOSES_ICD_COLNAME)==TRUE) {stop("Please Enter DIAGNOSES_ICD_COLNAME")}
    if (vector.is.empty(DIAGNOSES_DATE_COLNAME)==TRUE) {stop("Please Enter DIAGNOSES_DATE_COLNAME")}

    if (is.character(PRESCRIPTION_ID_COLNAME)==FALSE) {stop("Please Change Variable Type of PRESCRIPTION_ID_COLNAME to Character")}
    if (is.character(PRESCRIPTION_ATC_COLNAME)==FALSE) {stop("Please Change Variable Type of PRESCRIPTION_ATC_COLNAME to Character")}
    if (is.character(PRESCRIPTION_DATE_COLNAME)==FALSE) {stop("Please Change Variable Type of PRESCRIPTION_DATE_COLNAME to Character")}

    if (is.character(DIAGNOSES_ID_COLNAME)==FALSE) {stop("Please Change Variable Type of DIAGNOSES_ID_COLNAME to Character")}
    if (is.character(DIAGNOSES_ICD_COLNAME)==FALSE) {stop("Please Change Variable Type of DIAGNOSES_ICD_COLNAME to Character")}
    if (is.character(DIAGNOSES_DATE_COLNAME)==FALSE) {stop("Please Change Variable Type of DIAGNOSES_DATE_COLNAME to Character")}

    PRESCRIPTION$ATC <- PRESCRIPTION[[PRESCRIPTION_ATC_COLNAME]]
    PRESCRIPTION$ID <- PRESCRIPTION[[PRESCRIPTION_ID_COLNAME]]
    PRESCRIPTION$DATE <- PRESCRIPTION[[PRESCRIPTION_DATE_COLNAME]]

    PRESCRIPTION <- PRESCRIPTION %>%
      select(ID,ATC,DATE)

    DIAGNOSES$ICD <- DIAGNOSES[[DIAGNOSES_ICD_COLNAME]]
    DIAGNOSES$ID <- DIAGNOSES[[DIAGNOSES_ID_COLNAME]]
    DIAGNOSES$DATE <- DIAGNOSES[[DIAGNOSES_DATE_COLNAME]]

    DIAGNOSES <- DIAGNOSES %>%
      select(ID,ICD,DATE)
  }
  if (vector.is.empty(ATC_INPUT)==FALSE && vector.is.empty(ICD_INPUT)==TRUE) {
    if (is.character(ATC_INPUT)==FALSE){stop("Please Change Variable Type of ATC_INPUT to Character")}

    if (vector.is.empty(PRESCRIPTION)==TRUE) {stop("Please Enter Name of Dataframe at PRESCRIPTION")}
    if (vector.is.empty(PRESCRIPTION_ID_COLNAME)==TRUE) {stop("Please Enter PRESCRIPTION_ID_COLNAME")}
    if (vector.is.empty(PRESCRIPTION_ATC_COLNAME)==TRUE) {stop("Please Enter PRESCRIPTION_ATC_COLNAME")}
    if (vector.is.empty(PRESCRIPTION_DATE_COLNAME)==TRUE) {stop("Please Enter PRESCRIPTION_DATE_COLNAME")}

    if (is.character(PRESCRIPTION_ID_COLNAME)==FALSE) {stop("Please Change Variable Type of PRESCRIPTION_ID_COLNAME to Character")}
    if (is.character(PRESCRIPTION_ATC_COLNAME)==FALSE) {stop("Please Change Variable Type of PRESCRIPTION_ATC_COLNAME to Character")}
    if (is.character(PRESCRIPTION_DATE_COLNAME)==FALSE) {stop("Please Change Variable Type of PRESCRIPTION_DATE_COLNAME to Character")}

    PRESCRIPTION$ATC <- PRESCRIPTION[[PRESCRIPTION_ATC_COLNAME]]
    PRESCRIPTION$ID <- PRESCRIPTION[[PRESCRIPTION_ID_COLNAME]]
    PRESCRIPTION$DATE <- PRESCRIPTION[[PRESCRIPTION_DATE_COLNAME]]

    PRESCRIPTION <- PRESCRIPTION %>%
      select(ID,ATC,DATE)

  }
  if (vector.is.empty(ATC_INPUT)==TRUE && vector.is.empty(ICD_INPUT)==FALSE) {
    if (is.character(ICD_INPUT)==FALSE){stop("Please Change Variable Type of ICD_INPUT to Character")}

    if (vector.is.empty(DIAGNOSES)==TRUE) {stop("Please Enter Name of Dataframe at DIAGNOSES")}
    if (vector.is.empty(DIAGNOSES_ID_COLNAME)==TRUE) {stop("Please Enter DIAGNOSES_ID_COLNAME")}
    if (vector.is.empty(DIAGNOSES_ICD_COLNAME)==TRUE) {stop("Please Enter DIAGNOSES_ICD_COLNAME")}
    if (vector.is.empty(DIAGNOSES_DATE_COLNAME)==TRUE) {stop("Please Enter DIAGNOSES_DATE_COLNAME")}

    if (is.character(DIAGNOSES_ID_COLNAME)==FALSE) {stop("Please Change Variable Type of DIAGNOSES_ID_COLNAME to Character")}
    if (is.character(DIAGNOSES_ICD_COLNAME)==FALSE) {stop("Please Change Variable Type of DIAGNOSES_ICD_COLNAME to Character")}
    if (is.character(DIAGNOSES_DATE_COLNAME)==FALSE) {stop("Please Change Variable Type of DIAGNOSES_DATE_COLNAME to Character")}

    DIAGNOSES$ICD <- DIAGNOSES[[DIAGNOSES_ICD_COLNAME]]
    DIAGNOSES$ID <- DIAGNOSES[[DIAGNOSES_ID_COLNAME]]
    DIAGNOSES$DATE <- DIAGNOSES[[DIAGNOSES_DATE_COLNAME]]

    DIAGNOSES <- DIAGNOSES %>%
      select(ID,ICD,DATE)

  }
  if (vector.is.empty(ATC_INPUT)==TRUE && vector.is.empty(ICD_INPUT)==TRUE) {
    stop("Please Enter ATC or ICD to filter for !")
  }
  progress(2, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
  #______________________________________________________________________________________Define Dataframes

  STARTDATE <- as.Date(STARTDATE, format = STARTDATE_Format)
  if(STUDYDESIGN == "PraevalentUser"){
    INDEXDATE_PRAEVALENT <- as.Date(INDEXDATE_PRAEVALENT, format = INDEXDATE_PRAEVALENT_FORMAT)}
  progress(3, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
  #______________________________________________________________________________________Search

  if (vector.is.empty(ATC_INPUT)==FALSE && vector.is.empty(ICD_INPUT)==FALSE) {
    #ATC und ICD
    if(STUDYDESIGN == "NewUser"){
      #________________________________________________________________________Filter for ATC________________________________________________

      ATCfiltered <- PRESCRIPTION %>%
        filter(grepl(paste(ATC_INPUT, collapse="|"), PRESCRIPTION$ATC)) #Grepl Filter der PRESCRIPTION

      IDpat <- unique(ATCfiltered$ID)

      progress(4, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Filter for ICD________________________________________________

      DIAGfiltered <- DIAGNOSES %>%
        filter(grepl(paste(ICD_INPUT, collapse="|"), DIAGNOSES$ICD)) ##Grepl Filter der DIAGNOSES und nach Qualität Gesichert

      AMBDIAG <- DIAGfiltered %>% #Raussuchen der Patienten aus den gefilterten DIAGNOSES
        filter(DIAGfiltered$ID %in% IDpat)

      IDpat <- unique(AMBDIAG$ID)
      progress(5, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________IndexDATE________________________________________________

      if(INDEXTYPE == "ATC"){
        Indexframe <- ATCfiltered %>%
          filter(ATCfiltered$ID %in% IDpat)

        datalist <- split(Indexframe, Indexframe$ID) #Listen erzeugung für apply-function
        datalist <- map(datalist,getindexDATEATC) #erstellen der Indexdaten liste durch apply() der Methode
        Indexdaten <- rbindlist(datalist) #Umwandeln Liste in Dataframe
      }
      else if (INDEXTYPE == "ICD"){
        Indexframe <- DIAGfiltered %>%
          filter(DIAGfiltered$ID %in% IDpat)

        datalist <- split(Indexframe, Indexframe$ID) #Listen erzeugung für apply-function


        datalist <- map(datalist,getindexDATEICD) #erstellen der Indexdaten liste durch apply() der Methode
        Indexdaten <- rbindlist(datalist) #Umwandeln Liste in Dataframe
      }
      else{stop("Please Enter Correct Type of Indexdate!")}
      progress(6, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)


      #________________________________________________________________________PRELIMINARY_TIME_SPAN________________________________________________

      if(vector.is.empty(PRELIMINARY_TIME_SPAN) == FALSE){

        Indexdaten$STARTDATE <- STARTDATE

        Indexdaten <- Indexdaten %>%
          distinct()

        Indexdaten$DATEDIFF <- Indexdaten$DATEIndex - Indexdaten$STARTDATE

        Indexdaten <- Indexdaten %>%
          filter(Indexdaten$DATEDIFF >= PRELIMINARY_TIME_SPAN)
      }
      progress(7, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________DIAG vor Index________________________________________________

      if(INDEXTYPE == "ATC"){

        AMBDIAGsafe <- AMBDIAG
        DiagvorIndex <- merge(AMBDIAGsafe,Indexdaten, by="ID")

        DiagvorIndex <- DiagvorIndex %>%
          select(ID,DATEIndex,DATE) %>%
          distinct()

        datalist <- split(DiagvorIndex, DiagvorIndex$ID)

        datalist <- map(datalist, firstdateDIAG)
        DiagvorIndex <- rbindlist(datalist)

        DiagvorIndex <- DiagvorIndex %>%
          mutate(YEARvorIndex =  DiagvorIndex$DATEIndex - PRELIMINARY_TIME_SPAN) %>%
          select(ID,DATEIndex,ErstdiagnoseDIAG,YEARvorIndex) %>%
          distinct()

        DiagvorIndex <- DiagvorIndex %>%
          filter(DiagvorIndex$YEARvorIndex < DiagvorIndex$ErstdiagnoseDIAG) #< DiagvorIndex$datalist.DATEIndex)

        DiagvorIndex <- DiagvorIndex %>%
          filter(DiagvorIndex$ErstdiagnoseDIAG < DiagvorIndex$DATEIndex) #< DiagvorIndex$datalist.DATEIndex)

        DiagvorIndex <- DiagvorIndex %>%
          select(ID,DATEIndex) %>%
          distinct()

        Indexdaten <- DiagvorIndex
      }
      progress(8, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Exclusion ATC/ICD________________________________________________

      if(vector.is.empty(EXCLUSION_ATC) == FALSE){
        vorIndexfiltered <- filter(PRESCRIPTION, grepl(paste(EXCLUSION_ATC, collapse="|"), PRESCRIPTION$ATC)) #Grepl Filter der PRESCRIPTION

        vorIndex <- vorIndexfiltered %>%
          filter(vorIndexfiltered$ID %in% Indexdaten$ID)

        PatIndexdaten <- Indexdaten %>%
          select(ID,DATEIndex)

        vorIndex <- merge(vorIndex,PatIndexdaten, by="ID")

        vorIndex <- vorIndex %>%
          filter(vorIndex$DATE < vorIndex$DATEIndex)

        vorIndex <- vorIndex %>%
          filter((vorIndex$DATEIndex - vorIndex$DATE) < PRELIMINARY_TIME_SPAN)

        Idstofilter <- unique(vorIndex$ID)

        datalist <- split(PatIndexdaten,PatIndexdaten$ID)

        datalist[which(names(datalist) %in% Idstofilter)] <- NULL

        VoEXCLUSION_ATC <- rbindlist(datalist)

        Indexdaten <- VoEXCLUSION_ATC
      }

      if(vector.is.empty(EXCLUSION_ICD) == FALSE){

        vorIndexfiltered <- filter(DIAGNOSES, grepl(paste(EXCLUSION_ICD, collapse="|"), DIAGNOSES$ICD)) #Grepl Filter der PRESCRIPTION

        vorIndex <- vorIndexfiltered %>%
          filter(vorIndexfiltered$ID %in% Indexdaten$ID)

        PatIndexdaten <- Indexdaten %>%
          select(ID,DATEIndex)

        vorIndex <- merge(vorIndex,PatIndexdaten, by="ID")

        vorIndex <- vorIndex %>%
          filter(vorIndex$DATE < vorIndex$DATEIndex)

        vorIndex <- vorIndex %>%
          filter((vorIndex$DATEIndex - vorIndex$DATE) < PRELIMINARY_TIME_SPAN)

        Idstofilter <- unique(vorIndex$ID)

        datalist <- split(PatIndexdaten,PatIndexdaten$ID)

        datalist[which(names(datalist) %in% Idstofilter)] <- NULL

        VoEXCLUSION_ICD <- rbindlist(datalist)

        Indexdaten <- VoEXCLUSION_ICD
      }

      #________________________________________________________________________Exclusion AGE________________________________________________

      if(vector.is.empty(MIN_INCLUSION_AGE) == FALSE){
        PatAge <- INSURANTS %>%
          filter(INSURANTS$ID %in% Indexdaten$ID) #Selektion der entsprechenden ID's aus den versichertendaten

        Agecalcframe <- PatAge %>%
          select(ID,BIRTHYEAR) %>%
          distinct()

        Agecalcframe <- merge(Agecalcframe, Indexdaten, by="ID")

        Agecalcframe$DATEIndex <- format(Agecalcframe$DATEIndex, "%Y")
        Agecalcframe$DATEIndex <- as.numeric(Agecalcframe$DATEIndex)

        Agecalcframe <- Agecalcframe  %>%
          filter((Agecalcframe$DATEIndex-Agecalcframe$BIRTHYEAR)>MIN_INCLUSION_AGE) #Selektion der PAtienten mit älter als Einschlussalter

        AgeID <- unique(Agecalcframe$ID)

        Indexdaten <- Indexdaten  %>%
          filter(Indexdaten$ID %in% AgeID) #Selektion der entsprechenden ID's aus den versichertendaten
      }
      progress(9, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Mindestmenge VO________________________________________________

      if(vector.is.empty(MIN_NUM_PRESCRIPTION) == FALSE){

        ATCfiltered <- PRESCRIPTION %>%
          filter(grepl(paste(ATC_INPUT, collapse="|"), PRESCRIPTION$ATC)) #Grepl Filter der PRESCRIPTION

        PatMengeVO <- ATCfiltered %>%
          filter(ATCfiltered$ID %in% Indexdaten$ID)

        response.split <- split(PatMengeVO, PatMengeVO$ID)


        countmedis <- map(response.split, countmedi, ATC_INPUT)

        MedikamentenAnzahl <- rbindlist(countmedis)

        MedikamentenAnzahl <- MedikamentenAnzahl %>%
          filter(MedikamentenAnzahl$COUNT >= MIN_NUM_PRESCRIPTION) %>%
          distinct()

        Indexdaten <- Indexdaten %>%
          filter(Indexdaten$ID %in% MedikamentenAnzahl$ID)
      }

    }
    if(STUDYDESIGN == "PraevalentUser"){
      #________________________________________________________________________Filter for ATC________________________________________________

      ATCfiltered <- PRESCRIPTION %>%
        filter(grepl(paste(ATC_INPUT, collapse="|"), PRESCRIPTION$ATC)) #Grepl Filter der PRESCRIPTION

      IDpat <- unique(ATCfiltered$ID)

      #IDpat <- sample(IDpat, 100, replace = FALSE)
      progress(4, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
      #________________________________________________________________________Filter for ICD________________________________________________

      DIAGfiltered <- DIAGNOSES %>%
        filter(grepl(paste(ICD_INPUT, collapse="|"), DIAGNOSES$ICD)) ##Grepl Filter der DIAGNOSES und nach Qualität Gesichert

      AMBDIAG <- DIAGfiltered %>% #Raussuchen der Patienten aus den gefilterten DIAGNOSES
        filter(DIAGfiltered$ID %in% IDpat)

      IDpat <- unique(AMBDIAG$ID)
      progress(5, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
      #________________________________________________________________________IndexDATE____________________________________________________

      Indexframe <- DIAGfiltered %>%
        filter(DIAGfiltered$ID %in% IDpat)

      datalist <- split(Indexframe, Indexframe$ID) #Listen erzeugung für apply-function


      datalist <- map(datalist,getindexDATEICD) #erstellen der Indexdaten liste durch apply() der Methode
      Indexdaten <- rbindlist(datalist) #Umwandeln Liste in Dataframe

      Indexdaten$DATEIndex <- INDEXDATE_PRAEVALENT
      progress(6, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________PRELIMINARY_TIME_SPAN_________________________________________

      if(vector.is.empty(PRELIMINARY_TIME_SPAN) == FALSE){

        Indexdaten$STARTDATE <- STARTDATE

        Indexdaten <- Indexdaten %>%
          distinct()

        Indexdaten$DATEDIFF <- Indexdaten$DATEIndex - Indexdaten$STARTDATE

        Indexdaten <- Indexdaten %>%
          filter(Indexdaten$DATEDIFF >= PRELIMINARY_TIME_SPAN)
      }
      progress(7, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________DIAG vor Index________________________________________________

      if(INDEXTYPE == "ATC"){

        AMBDIAGsafe <- AMBDIAG
        DiagvorIndex <- merge(AMBDIAGsafe,Indexdaten, by="ID")

        DiagvorIndex <- DiagvorIndex %>%
          select(ID,DATEIndex,DATE) %>%
          distinct()

        datalist <- split(DiagvorIndex, DiagvorIndex$ID)

        datalist <- map(datalist, firstdateDIAG)
        DiagvorIndex <- rbindlist(datalist)

        DiagvorIndex <- DiagvorIndex %>%
          mutate(YEARvorIndex =  DiagvorIndex$DATEIndex - PRELIMINARY_TIME_SPAN) %>%
          select(ID,DATEIndex,ErstdiagnoseDIAG,YEARvorIndex) %>%
          distinct()

        DiagvorIndex <- DiagvorIndex %>%
          filter(DiagvorIndex$YEARvorIndex < DiagvorIndex$ErstdiagnoseDIAG) #< DiagvorIndex$datalist.DATEIndex)

        DiagvorIndex <- DiagvorIndex %>%
          filter(DiagvorIndex$ErstdiagnoseDIAG < DiagvorIndex$DATEIndex) #< DiagvorIndex$datalist.DATEIndex)

        DiagvorIndex <- DiagvorIndex %>%
          select(ID,DATEIndex) %>%
          distinct()

        Indexdaten <- DiagvorIndex
      }

      #________________________________________________________________________Exclusion ATC/ICD________________________________________________

      if(vector.is.empty(EXCLUSION_ATC) == FALSE){
        vorIndexfiltered <- filter(PRESCRIPTION, grepl(paste(EXCLUSION_ATC, collapse="|"), PRESCRIPTION$ATC)) #Grepl Filter der PRESCRIPTION

        vorIndex <- vorIndexfiltered %>%
          filter(vorIndexfiltered$ID %in% Indexdaten$ID)

        PatIndexdaten <- Indexdaten %>%
          select(ID,DATEIndex)

        vorIndex <- merge(vorIndex,PatIndexdaten, by="ID")

        vorIndex <- vorIndex %>%
          filter(vorIndex$DATE < vorIndex$DATEIndex)

        vorIndex <- vorIndex %>%
          filter((vorIndex$DATEIndex - vorIndex$DATE) < PRELIMINARY_TIME_SPAN)

        Idstofilter <- unique(vorIndex$ID)

        datalist <- split(PatIndexdaten,PatIndexdaten$ID)

        datalist[which(names(datalist) %in% Idstofilter)] <- NULL

        VoEXCLUSION_ATC <- rbindlist(datalist)

        Indexdaten <- VoEXCLUSION_ATC
      }

      if(vector.is.empty(EXCLUSION_ICD) == FALSE){

        vorIndexfiltered <- filter(DIAGNOSES, grepl(paste(EXCLUSION_ICD, collapse="|"), DIAGNOSES$ICD)) #Grepl Filter der PRESCRIPTION

        vorIndex <- vorIndexfiltered %>%
          filter(vorIndexfiltered$ID %in% Indexdaten$ID)

        PatIndexdaten <- Indexdaten %>%
          select(ID,DATEIndex)

        vorIndex <- merge(vorIndex,PatIndexdaten, by="ID")

        vorIndex <- vorIndex %>%
          filter(vorIndex$DATE < vorIndex$DATEIndex)

        vorIndex <- vorIndex %>%
          filter((vorIndex$DATEIndex - vorIndex$DATE) < PRELIMINARY_TIME_SPAN)

        Idstofilter <- unique(vorIndex$ID)

        datalist <- split(PatIndexdaten,PatIndexdaten$ID)

        datalist[which(names(datalist) %in% Idstofilter)] <- NULL

        VoEXCLUSION_ICD <- rbindlist(datalist)

        Indexdaten <- VoEXCLUSION_ICD
      }

      progress(8, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Exclusion AGE________________________________________________

      if(vector.is.empty(MIN_INCLUSION_AGE) == FALSE){
        PatAge <- INSURANTS %>%
          filter(INSURANTS$ID %in% Indexdaten$ID) #Selektion der entsprechenden ID's aus den versichertendaten

        Agecalcframe <- PatAge %>%
          select(ID,BIRTHYEAR) %>%
          distinct()

        Agecalcframe <- merge(Agecalcframe, Indexdaten, by="ID")

        Agecalcframe$DATEIndex <- format(Agecalcframe$DATEIndex, "%Y")
        Agecalcframe$DATEIndex <- as.numeric(Agecalcframe$DATEIndex)

        Agecalcframe <- Agecalcframe  %>%
          filter((Agecalcframe$DATEIndex-Agecalcframe$BIRTHYEAR)>MIN_INCLUSION_AGE) #Selektion der PAtienten mit älter als Einschlussalter

        AgeID <- unique(Agecalcframe$ID)

        Indexdaten <- Indexdaten  %>%
          filter(Indexdaten$ID %in% AgeID) #Selektion der entsprechenden ID's aus den versichertendaten
      }

      progress(9, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Mindestmenge VO________________________________________________

      if(vector.is.empty(MIN_NUM_PRESCRIPTION) == FALSE){

        ATCfiltered <- PRESCRIPTION %>%
          filter(grepl(paste(ATC_INPUT, collapse="|"), PRESCRIPTION$ATC)) #Grepl Filter der PRESCRIPTION

        PatMengeVO <- ATCfiltered %>%
          filter(ATCfiltered$ID %in% Indexdaten$ID)

        response.split <- split(PatMengeVO, PatMengeVO$ID)


        countmedis <- map(response.split, countmedi, ATC_INPUT)

        MedikamentenAnzahl <- rbindlist(countmedis)

        MedikamentenAnzahl <- MedikamentenAnzahl %>%
          filter(MedikamentenAnzahl$COUNT >= MIN_NUM_PRESCRIPTION) %>%
          distinct()

        Indexdaten <- Indexdaten %>%
          filter(Indexdaten$ID %in% MedikamentenAnzahl$ID)
      }
    }
  }#

  if (vector.is.empty(ATC_INPUT)==FALSE && vector.is.empty(ICD_INPUT)==TRUE) {
    #ATC
    if(STUDYDESIGN == "NewUser"){

      progress(4, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Filter for ATC________________________________________________

      ATCfiltered <- PRESCRIPTION %>%
        filter(grepl(paste(ATC_INPUT, collapse="|"), PRESCRIPTION$ATC)) #Grepl Filter der PRESCRIPTION

      IDpat <- unique(ATCfiltered$ID)

      progress(5, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________IndexDATE________________________________________________
      if(INDEXTYPE == "ATC"){
        Indexframe <- ATCfiltered %>%
          filter(ATCfiltered$ID %in% IDpat)

        datalist <- split(Indexframe, Indexframe$ID) #Listen erzeugung für apply-function
        datalist <- map(datalist,getindexDATEATC) #erstellen der Indexdaten liste durch apply() der Methode
        Indexdaten <- rbindlist(datalist) #Umwandeln Liste in Dataframe
      }
      else if (INDEXTYPE == "ICD"){
        stop("Please Enter Correct Type of Indexdate!")
      }
      else{stop("Please Enter Correct Type of Indexdate!")}
      progress(6, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________PRELIMINARY_TIME_SPAN________________________________________________

      if(vector.is.empty(PRELIMINARY_TIME_SPAN) == FALSE){

        Indexdaten$STARTDATE <- STARTDATE

        Indexdaten <- Indexdaten %>%
          distinct()

        Indexdaten$DATEDIFF <- Indexdaten$DATEIndex - Indexdaten$STARTDATE

        Indexdaten <- Indexdaten %>%
          filter(Indexdaten$DATEDIFF >= PRELIMINARY_TIME_SPAN)
      }
      progress(7, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Exclusion ATC/ICD________________________________________________

      if(vector.is.empty(EXCLUSION_ATC) == FALSE){
        vorIndexfiltered <- filter(PRESCRIPTION, grepl(paste(EXCLUSION_ATC, collapse="|"), PRESCRIPTION$ATC)) #Grepl Filter der PRESCRIPTION

        vorIndex <- vorIndexfiltered %>%
          filter(vorIndexfiltered$ID %in% Indexdaten$ID)

        PatIndexdaten <- Indexdaten %>%
          select(ID,DATEIndex)

        vorIndex <- merge(vorIndex,PatIndexdaten, by="ID")

        vorIndex <- vorIndex %>%
          filter(vorIndex$DATE < vorIndex$DATEIndex)

        vorIndex <- vorIndex %>%
          filter((vorIndex$DATEIndex - vorIndex$DATE) < PRELIMINARY_TIME_SPAN)

        Idstofilter <- unique(vorIndex$ID)

        datalist <- split(PatIndexdaten,PatIndexdaten$ID)

        datalist[which(names(datalist) %in% Idstofilter)] <- NULL

        VoEXCLUSION_ATC <- rbindlist(datalist)

        Indexdaten <- VoEXCLUSION_ATC
      }

      if(vector.is.empty(EXCLUSION_ICD) == FALSE){

        vorIndexfiltered <- filter(DIAGNOSES, grepl(paste(EXCLUSION_ICD, collapse="|"), DIAGNOSES$ICD)) #Grepl Filter der PRESCRIPTION

        vorIndex <- vorIndexfiltered %>%
          filter(vorIndexfiltered$ID %in% Indexdaten$ID)

        PatIndexdaten <- Indexdaten %>%
          select(ID,DATEIndex)

        vorIndex <- merge(vorIndex,PatIndexdaten, by="ID")

        vorIndex <- vorIndex %>%
          filter(vorIndex$DATE < vorIndex$DATEIndex)

        vorIndex <- vorIndex %>%
          filter((vorIndex$DATEIndex - vorIndex$DATE) < PRELIMINARY_TIME_SPAN)

        Idstofilter <- unique(vorIndex$ID)

        datalist <- split(PatIndexdaten,PatIndexdaten$ID)

        datalist[which(names(datalist) %in% Idstofilter)] <- NULL

        VoEXCLUSION_ICD <- rbindlist(datalist)

        Indexdaten <- VoEXCLUSION_ICD
      }
      progress(8, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Exclusion AGE________________________________________________

      if(vector.is.empty(MIN_INCLUSION_AGE) == FALSE){
        PatAge <- INSURANTS %>%
          filter(INSURANTS$ID %in% Indexdaten$ID) #Selektion der entsprechenden ID's aus den versichertendaten

        Agecalcframe <- PatAge %>%
          select(ID,BIRTHYEAR) %>%
          distinct()

        Agecalcframe <- merge(Agecalcframe, Indexdaten, by="ID")

        Agecalcframe$DATEIndex <- format(Agecalcframe$DATEIndex, "%Y")
        Agecalcframe$DATEIndex <- as.numeric(Agecalcframe$DATEIndex)

        Agecalcframe <- Agecalcframe  %>%
          filter((Agecalcframe$DATEIndex-Agecalcframe$BIRTHYEAR)>MIN_INCLUSION_AGE) #Selektion der PAtienten mit älter als Einschlussalter

        AgeID <- unique(Agecalcframe$ID)

        Indexdaten <- Indexdaten  %>%
          filter(Indexdaten$ID %in% AgeID) #Selektion der entsprechenden ID's aus den versichertendaten
      }
      progress(9, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Mindestmenge VO________________________________________________

      if(vector.is.empty(MIN_NUM_PRESCRIPTION) == FALSE){

        ATCfiltered <- PRESCRIPTION %>%
          filter(grepl(paste(ATC_INPUT, collapse="|"), PRESCRIPTION$ATC)) #Grepl Filter der PRESCRIPTION

        PatMengeVO <- ATCfiltered %>%
          filter(ATCfiltered$ID %in% Indexdaten$ID)

        response.split <- split(PatMengeVO, PatMengeVO$ID)


        countmedis <- map(response.split, countmedi, ATC_INPUT)

        MedikamentenAnzahl <- rbindlist(countmedis)

        MedikamentenAnzahl <- MedikamentenAnzahl %>%
          filter(MedikamentenAnzahl$COUNT >= MIN_NUM_PRESCRIPTION) %>%
          distinct()

        Indexdaten <- Indexdaten %>%
          filter(Indexdaten$ID %in% MedikamentenAnzahl$ID)
      }
    }
    if(STUDYDESIGN == "PraevalentUser"){
      #________________________________________________________________________Filter for ATC________________________________________________

      ATCfiltered <- PRESCRIPTION %>%
        filter(grepl(paste(ATC_INPUT, collapse="|"), PRESCRIPTION$ATC)) #Grepl Filter der PRESCRIPTION

      IDpat <- unique(ATCfiltered$ID)
      progress(4, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
      #________________________________________________________________________IndexDATE____________________________________________________

      Indexframe <- DIAGfiltered %>%
        filter(DIAGfiltered$ID %in% IDpat)

      datalist <- split(Indexframe, Indexframe$ID) #Listen erzeugung für apply-function


      datalist <- map(datalist,getindexDATEICD) #erstellen der Indexdaten liste durch apply() der Methode
      Indexdaten <- rbindlist(datalist) #Umwandeln Liste in Dataframe

      Indexdaten$DATEIndex <- INDEXDATE_PRAEVALENT

      progress(5, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________PRELIMINARY_TIME_SPAN_________________________________________

      if(vector.is.empty(PRELIMINARY_TIME_SPAN) == FALSE){

        Indexdaten$STARTDATE <- STARTDATE

        Indexdaten <- Indexdaten %>%
          distinct()

        Indexdaten$DATEDIFF <- Indexdaten$DATEIndex - Indexdaten$STARTDATE

        Indexdaten <- Indexdaten %>%
          filter(Indexdaten$DATEDIFF >= PRELIMINARY_TIME_SPAN)
      }
      progress(6, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Exclusion ATC/ICD________________________________________________

      if(vector.is.empty(EXCLUSION_ATC) == FALSE){
        vorIndexfiltered <- filter(PRESCRIPTION, grepl(paste(EXCLUSION_ATC, collapse="|"), PRESCRIPTION$ATC)) #Grepl Filter der PRESCRIPTION

        vorIndex <- vorIndexfiltered %>%
          filter(vorIndexfiltered$ID %in% Indexdaten$ID)

        PatIndexdaten <- Indexdaten %>%
          select(ID,DATEIndex)

        vorIndex <- merge(vorIndex,PatIndexdaten, by="ID")

        vorIndex <- vorIndex %>%
          filter(vorIndex$DATE < vorIndex$DATEIndex)

        vorIndex <- vorIndex %>%
          filter((vorIndex$DATEIndex - vorIndex$DATE) < PRELIMINARY_TIME_SPAN)

        Idstofilter <- unique(vorIndex$ID)

        datalist <- split(PatIndexdaten,PatIndexdaten$ID)

        datalist[which(names(datalist) %in% Idstofilter)] <- NULL

        VoEXCLUSION_ATC <- rbindlist(datalist)

        Indexdaten <- VoEXCLUSION_ATC
      }

      if(vector.is.empty(EXCLUSION_ICD) == FALSE){

        vorIndexfiltered <- filter(DIAGNOSES, grepl(paste(EXCLUSION_ICD, collapse="|"), DIAGNOSES$ICD)) #Grepl Filter der PRESCRIPTION

        vorIndex <- vorIndexfiltered %>%
          filter(vorIndexfiltered$ID %in% Indexdaten$ID)

        PatIndexdaten <- Indexdaten %>%
          select(ID,DATEIndex)

        vorIndex <- merge(vorIndex,PatIndexdaten, by="ID")

        vorIndex <- vorIndex %>%
          filter(vorIndex$DATE < vorIndex$DATEIndex)

        vorIndex <- vorIndex %>%
          filter((vorIndex$DATEIndex - vorIndex$DATE) < PRELIMINARY_TIME_SPAN)

        Idstofilter <- unique(vorIndex$ID)

        datalist <- split(PatIndexdaten,PatIndexdaten$ID)

        datalist[which(names(datalist) %in% Idstofilter)] <- NULL

        VoEXCLUSION_ICD <- rbindlist(datalist)

        Indexdaten <- VoEXCLUSION_ICD
      }
      progress(7, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Exclusion AGE________________________________________________

      if(vector.is.empty(MIN_INCLUSION_AGE) == FALSE){
        PatAge <- INSURANTS %>%
          filter(INSURANTS$ID %in% Indexdaten$ID) #Selektion der entsprechenden ID's aus den versichertendaten

        Agecalcframe <- PatAge %>%
          select(ID,BIRTHYEAR) %>%
          distinct()

        Agecalcframe <- merge(Agecalcframe, Indexdaten, by="ID")

        Agecalcframe$DATEIndex <- format(Agecalcframe$DATEIndex, "%Y")
        Agecalcframe$DATEIndex <- as.numeric(Agecalcframe$DATEIndex)

        Agecalcframe <- Agecalcframe  %>%
          filter((Agecalcframe$DATEIndex-Agecalcframe$BIRTHYEAR)>MIN_INCLUSION_AGE) #Selektion der PAtienten mit älter als Einschlussalter

        AgeID <- unique(Agecalcframe$ID)

        Indexdaten <- Indexdaten  %>%
          filter(Indexdaten$ID %in% AgeID) #Selektion der entsprechenden ID's aus den versichertendaten
      }
      progress(8, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Mindestmenge VO________________________________________________

      if(vector.is.empty(MIN_NUM_PRESCRIPTION) == FALSE){

        ATCfiltered <- PRESCRIPTION %>%
          filter(grepl(paste(ATC_INPUT, collapse="|"), PRESCRIPTION$ATC)) #Grepl Filter der PRESCRIPTION

        PatMengeVO <- ATCfiltered %>%
          filter(ATCfiltered$ID %in% Indexdaten$ID)

        response.split <- split(PatMengeVO, PatMengeVO$ID)


        countmedis <- map(response.split, countmedi, ATC_INPUT)

        MedikamentenAnzahl <- rbindlist(countmedis)

        MedikamentenAnzahl <- MedikamentenAnzahl %>%
          filter(MedikamentenAnzahl$COUNT >= MIN_NUM_PRESCRIPTION) %>%
          distinct()

        Indexdaten <- Indexdaten %>%
          filter(Indexdaten$ID %in% MedikamentenAnzahl$ID)}
      progress(9, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

    }
  }#

  if (vector.is.empty(ATC_INPUT)==TRUE && vector.is.empty(ICD_INPUT)==FALSE) {
    #ICD
    if(STUDYDESIGN == "NewUser"){
      #________________________________________________________________________Filter for ICD________________________________________________

      DIAGfiltered <- DIAGNOSES %>%
        filter(grepl(paste(ICD_INPUT, collapse="|"), DIAGNOSES$ICD)) ##Grepl Filter der DIAGNOSES und nach Qualität Gesichert

      AMBDIAG <- DIAGfiltered

      IDpat <- unique(AMBDIAG$ID)
      progress(4, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________IndexDATE________________________________________________
      if(INDEXTYPE == "ATC"){
        stop("Please Enter Correct Type of Indexdate!")
      }
      else if (INDEXTYPE == "ICD"){
        Indexframe <- DIAGfiltered %>%
          filter(DIAGfiltered$ID %in% IDpat)

        datalist <- split(Indexframe, Indexframe$ID) #Listen erzeugung für apply-function


        datalist <- map(datalist,getindexDATEICD) #erstellen der Indexdaten liste durch apply() der Methode
        Indexdaten <- rbindlist(datalist) #Umwandeln Liste in Dataframe
      }
      else{stop("Please Enter Correct Type of Indexdate!")}

      progress(5, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________PRELIMINARY_TIME_SPAN________________________________________________

      if(vector.is.empty(PRELIMINARY_TIME_SPAN) == FALSE){

        Indexdaten$STARTDATE <- STARTDATE

        Indexdaten <- Indexdaten %>%
          distinct()

        Indexdaten$DATEDIFF <- Indexdaten$DATEIndex - Indexdaten$STARTDATE

        Indexdaten <- Indexdaten %>%
          filter(Indexdaten$DATEDIFF >= PRELIMINARY_TIME_SPAN)
      }
      progress(6, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Exclusion ATC/ICD________________________________________________

      if(vector.is.empty(EXCLUSION_ATC) == FALSE){
        vorIndexfiltered <- filter(PRESCRIPTION, grepl(paste(EXCLUSION_ATC, collapse="|"), PRESCRIPTION$ATC)) #Grepl Filter der PRESCRIPTION

        vorIndex <- vorIndexfiltered %>%
          filter(vorIndexfiltered$ID %in% Indexdaten$ID)

        PatIndexdaten <- Indexdaten %>%
          select(ID,DATEIndex)

        vorIndex <- merge(vorIndex,PatIndexdaten, by="ID")

        vorIndex <- vorIndex %>%
          filter(vorIndex$DATE < vorIndex$DATEIndex)

        vorIndex <- vorIndex %>%
          filter((vorIndex$DATEIndex - vorIndex$DATE) < PRELIMINARY_TIME_SPAN)

        Idstofilter <- unique(vorIndex$ID)

        datalist <- split(PatIndexdaten,PatIndexdaten$ID)

        datalist[which(names(datalist) %in% Idstofilter)] <- NULL

        VoEXCLUSION_ATC <- rbindlist(datalist)

        Indexdaten <- VoEXCLUSION_ATC
      }

      if(vector.is.empty(EXCLUSION_ICD) == FALSE){

        vorIndexfiltered <- filter(DIAGNOSES, grepl(paste(EXCLUSION_ICD, collapse="|"), DIAGNOSES$ICD)) #Grepl Filter der PRESCRIPTION

        vorIndex <- vorIndexfiltered %>%
          filter(vorIndexfiltered$ID %in% Indexdaten$ID)

        PatIndexdaten <- Indexdaten %>%
          select(ID,DATEIndex)

        vorIndex <- merge(vorIndex,PatIndexdaten, by="ID")

        vorIndex <- vorIndex %>%
          filter(vorIndex$DATE < vorIndex$DATEIndex)

        vorIndex <- vorIndex %>%
          filter((vorIndex$DATEIndex - vorIndex$DATE) < PRELIMINARY_TIME_SPAN)

        Idstofilter <- unique(vorIndex$ID)

        datalist <- split(PatIndexdaten,PatIndexdaten$ID)

        datalist[which(names(datalist) %in% Idstofilter)] <- NULL

        VoEXCLUSION_ICD <- rbindlist(datalist)

        Indexdaten <- VoEXCLUSION_ICD
      }
      progress(7, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Exclusion AGE________________________________________________

      progress(8, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      if(vector.is.empty(MIN_INCLUSION_AGE) == FALSE){
        PatAge <- INSURANTS %>%
          filter(INSURANTS$ID %in% Indexdaten$ID) #Selektion der entsprechenden ID's aus den versichertendaten

        Agecalcframe <- PatAge %>%
          select(ID,BIRTHYEAR) %>%
          distinct()

        Agecalcframe <- merge(Agecalcframe, Indexdaten, by="ID")

        Agecalcframe$DATEIndex <- format(Agecalcframe$DATEIndex, "%Y")
        Agecalcframe$DATEIndex <- as.numeric(Agecalcframe$DATEIndex)

        Agecalcframe <- Agecalcframe  %>%
          filter((Agecalcframe$DATEIndex-Agecalcframe$BIRTHYEAR)>MIN_INCLUSION_AGE) #Selektion der PAtienten mit älter als Einschlussalter

        AgeID <- unique(Agecalcframe$ID)

        Indexdaten <- Indexdaten  %>%
          filter(Indexdaten$ID %in% AgeID) #Selektion der entsprechenden ID's aus den versichertendaten
      }
      progress(9, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

    }
    if(STUDYDESIGN == "PraevalentUser"){
      progress(4, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Filter for ICD________________________________________________

      DIAGfiltered <- DIAGNOSES %>%
        filter(grepl(paste(ICD_INPUT, collapse="|"), DIAGNOSES$ICD)) ##Grepl Filter der DIAGNOSES und nach Qualität Gesichert

      AMBDIAG <- DIAGfiltered

      IDpat <- unique(AMBDIAG$ID)
      progress(5, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________IndexDATE____________________________________________________

      Indexframe <- DIAGfiltered %>%
        filter(DIAGfiltered$ID %in% IDpat)

      datalist <- split(Indexframe, Indexframe$ID) #Listen erzeugung für apply-function


      datalist <- map(datalist,getindexDATEICD) #erstellen der Indexdaten liste durch apply() der Methode
      Indexdaten <- rbindlist(datalist) #Umwandeln Liste in Dataframe

      Indexdaten$DATEIndex <- INDEXDATE_PRAEVALENT

      progress(6, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)


      #________________________________________________________________________PRELIMINARY_TIME_SPAN_________________________________________

      if(vector.is.empty(PRELIMINARY_TIME_SPAN) == FALSE){

        Indexdaten$STARTDATE <- STARTDATE

        Indexdaten <- Indexdaten %>%
          distinct()

        Indexdaten$DATEDIFF <- Indexdaten$DATEIndex - Indexdaten$STARTDATE

        Indexdaten <- Indexdaten %>%
          filter(Indexdaten$DATEDIFF >= PRELIMINARY_TIME_SPAN)
      }
      progress(7, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Exclusion ATC/ICD________________________________________________

      if(vector.is.empty(EXCLUSION_ATC) == FALSE){
        vorIndexfiltered <- filter(PRESCRIPTION, grepl(paste(EXCLUSION_ATC, collapse="|"), PRESCRIPTION$ATC)) #Grepl Filter der PRESCRIPTION

        vorIndex <- vorIndexfiltered %>%
          filter(vorIndexfiltered$ID %in% Indexdaten$ID)

        PatIndexdaten <- Indexdaten %>%
          select(ID,DATEIndex)

        vorIndex <- merge(vorIndex,PatIndexdaten, by="ID")

        vorIndex <- vorIndex %>%
          filter(vorIndex$DATE < vorIndex$DATEIndex)
        vorIndex <- vorIndex %>%
          filter((vorIndex$DATEIndex - vorIndex$DATE) < PRELIMINARY_TIME_SPAN)

        Idstofilter <- unique(vorIndex$ID)

        datalist <- split(PatIndexdaten,PatIndexdaten$ID)

        datalist[which(names(datalist) %in% Idstofilter)] <- NULL

        VoEXCLUSION_ATC <- rbindlist(datalist)

        Indexdaten <- VoEXCLUSION_ATC
      }

      if(vector.is.empty(EXCLUSION_ICD) == FALSE){

        vorIndexfiltered <- filter(DIAGNOSES, grepl(paste(EXCLUSION_ICD, collapse="|"), DIAGNOSES$ICD)) #Grepl Filter der PRESCRIPTION

        vorIndex <- vorIndexfiltered %>%
          filter(vorIndexfiltered$ID %in% Indexdaten$ID)

        PatIndexdaten <- Indexdaten %>%
          select(ID,DATEIndex)

        vorIndex <- merge(vorIndex,PatIndexdaten, by="ID")

        vorIndex <- vorIndex %>%
          filter(vorIndex$DATE < vorIndex$DATEIndex)

        vorIndex <- vorIndex %>%
          filter((vorIndex$DATEIndex - vorIndex$DATE) < PRELIMINARY_TIME_SPAN)

        Idstofilter <- unique(vorIndex$ID)

        datalist <- split(PatIndexdaten,PatIndexdaten$ID)

        datalist[which(names(datalist) %in% Idstofilter)] <- NULL

        VoEXCLUSION_ICD <- rbindlist(datalist)

        Indexdaten <- VoEXCLUSION_ICD
      }
      progress(8, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      #________________________________________________________________________Exclusion AGE________________________________________________
      progress(9, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

      if(vector.is.empty(MIN_INCLUSION_AGE) == FALSE){
        PatAge <- INSURANTS %>%
          filter(INSURANTS$ID %in% Indexdaten$ID) #Selektion der entsprechenden ID's aus den versichertendaten

        Agecalcframe <- PatAge %>%
          select(ID,BIRTHYEAR) %>%
          distinct()

        Agecalcframe <- merge(Agecalcframe, Indexdaten, by="ID")

        Agecalcframe$DATEIndex <- format(Agecalcframe$DATEIndex, "%Y")
        Agecalcframe$DATEIndex <- as.numeric(Agecalcframe$DATEIndex)

        Agecalcframe <- Agecalcframe  %>%
          filter((Agecalcframe$DATEIndex-Agecalcframe$BIRTHYEAR)>MIN_INCLUSION_AGE) #Selektion der PAtienten mit älter als Einschlussalter

        AgeID <- unique(Agecalcframe$ID)

        Indexdaten <- Indexdaten  %>%
          filter(Indexdaten$ID %in% AgeID) #Selektion der entsprechenden ID's aus den versichertendaten
      }

    }
  }#

  if (vector.is.empty(ATC_INPUT)==TRUE && vector.is.empty(ICD_INPUT)==TRUE) {
    stop("Please Enter ATC or ICD to filter for !")
  }
  options(warn=0)
  progress(10, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
  return(Indexdaten)
}













