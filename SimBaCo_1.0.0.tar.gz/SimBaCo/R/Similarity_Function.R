#' Similarity Finder Function
#'
#' Find Similar Patients to a Patient you choose
#'
#' @import cluster
#' @import comorbidity
#' @import varhandle
#' @import dplyr
#' @import formattable
#' @import ggplot2
#' @import feather
#' @import purrr
#' @import data.table
#' @import shiny
#' @import rlist
#' @import RColorBrewer
#' @import gridExtra
#' @import forcats
#' @import furrr
#' @import foreach
#' @import doParallel
#' @import stringr
#' @import parallel
#' @import snow
#' @import survival
#' @import survminer
#' @import pROC
#' @import factoextra
#' @import readr
#' @import Rtsne
#' @import iterators
#' @import UBL
#' @import svMisc
#' @import lubridate
#'
#'
#' @param PATIENT_SELECTION PATIENT_SELECTION, can be set to "NEW" or "IN_DF"
#' @param ANALYSIS_TYPE ANALYSIS_TYPE, could be "CLUSTER" or "NEAREST".
#' @param DISTANCE_MEASURE DISTANCE_MEASURE can be set to "GOWER" or "HEOM"
#' @param SELECT_COMORBIDITY SELECT_COMORBIDITY can be one of the comorbidities listed in the comorbidity package
#' @param PERCENT_CUT_OFF PERCENT_CUT_OFF, at which percentage of the nearest patient is the cut-off
#' @param PATIENT_SIMILAR_BIRTH_YEAR PATIENT_SIMILAR_BIRTH_YEAR, the year of birth for patient to match for
#' @param PATIENT_SIMILAR_SEX PATIENT_SIMILAR_SEX, the sex of the patient to match for
#' @param PATIENT_SIMILAR_INDEXDATE PATIENT_SIMILAR_INDEXDATE, the index date of the patient to match for
#' @param PATIENT_SIMILAR_INDEXDATE_FORMAT PATIENT_SIMILAR_INDEXDATE_FORMAT, date format of the field PATIENT_SIMILAR_INDEXDATE
#' @param PATIENT_SIMILAR_ATC PATIENT_SIMILAR_ATC, the ATC codes for the patient to match for
#' @param PATIENT_SIMILAR_ATC_COUNT PATIENT_SIMILAR_ATC_COUNT, the quantity of the ATC codes in the field PATIENT_SIMILAR_ATC
#' @param PATIENT_SIMILAR_ICD PATIENT_SIMILAR_ICD, the ICD codes for the patient to match for
#' @param PRESCRIPTION PRESCRIPTION, the name of the data frame containing the prescription data
#' @param PRESCRIPTION_ID_COLNAME PRESCRIPTION_ID_COLNAME, the name of the column containing the IDs in the data frame prescription
#' @param PRESCRIPTION_ATC_COLNAME PRESCRIPTION_ATC_COLNAME, the name of the column containing the ATC codes in the data frame prescription
#' @param DIAGNOSES DIAGNOSES, name of the data frame containing the diagnoses
#' @param DIAGNOSES_ID_COLNAME DIAGNOSES_ID_COLNAME, name of the column in the data frame DIAGNOSES containing the IDs
#' @param DIAGNOSES_ICD_COLNAME DIAGNOSES_ICD_COLNAME, name of the column in the data frame DIAGNOSES containing the ICD codes
#' @param DIAGNOSES_ICD_TYPE DIAGNOSES_ICD_TYPE, could be set to "icd10"or "icd09"
#' @param INSURANTS INSURANTS, name of the data frame containing the insurants' data
#' @param INSURANTS_ID_COLNAME INSURANTS_ID_COLNAME, name of the column in the data frame INSURANTS containing the patient IDs
#' @param INSURANTS_BIRTH_YEAR_COLNAME INSURANTS_BIRTH_YEAR_COLNAME, name of the column in the data frame INSURANTS containing the patients year of birth
#' @param INSURANTS_SEX_COLNAME INSURANTS_SEX_COLNAME, name of the column in the data frame INSURANTS containing the sex of the patients
#' @param INSURANTS_INDEXDATE_COLNAME INSURANTS_INDEXDATUM_COLNAME, name of the column in the data frame INSURANTS containing the patient index dates
#' @param PATIENT_SELECTION_ID PATIENT_SELECTION_ID, if a patient already existing in the data frame should be used enter the ID of the patient here (in combination with PATIENT_SELECTION = "IN_DF")
#'
#' @return Dataframe consisting of ID's of the nearest (if a new patient is enterred the patient could be found as ID = 9999999999999)
#'
#' @author Lucas Wirbka, \email{Lucas.Wirbka@@med.uni-heidelberg.de}
#'
#' @examples
#'
#'nearest30 <- Find_Similar(PATIENT_SELECTION = "NEW",
#'                          ANALYSIS_TYPE = "NEAREST",
#'                          DISTANCE_MEASURE = "GOWER",
#'                          SELECT_COMORBIDITY = c("chf","carit"),
#'                          PERCENT_CUT_OFF = 30,
#'                          PATIENT_SIMILAR_BIRTH_YEAR = 1930,
#'                          PATIENT_SIMILAR_SEX = "1",
#'                          PATIENT_SIMILAR_INDEXDATE = "20191030",
#'                          PATIENT_SIMILAR_INDEXDATE_FORMAT = "%Y%m%d",
#'                          PATIENT_SIMILAR_ATC = c("^C10","^D"),
#'                          PATIENT_SIMILAR_ATC_COUNT = c(10,3),
#'                          PATIENT_SIMILAR_ICD = c("I480","I101"),
#'                          PRESCRIPTION = VO_ready,
#'                          PRESCRIPTION_ATC_COLNAME = "ATC",
#'                          PRESCRIPTION_ID_COLNAME = "Versid",
#'                          DIAGNOSES = Diag_ready,
#'                          DIAGNOSES_ICD_COLNAME = "ICD",
#'                          DIAGNOSES_ID_COLNAME = "Versid.x",
#'                          DIAGNOSES_ICD_TYPE = "icd10",
#'                          INSURANTS = VERS_ready,
#'                          INSURANTS_ID_COLNAME = "Versid",
#'                          INSURANTS_BIRTH_YEAR_COLNAME = "Geburtsjahr",
#'                          INSURANTS_SEX_COLNAME = "Geschlecht",
#'                          INSURANTS_INDEXDATE_COLNAME = "datumIndex")
#'
#'
#'nearest30 <- Find_Similar(PATIENT_SELECTION = "IN_DF",
#'                          ANALYSIS_TYPE = "NEAREST",
#'                          DISTANCE_MEASURE = "GOWER",
#'                          ATIENT_SELECTION_ID = 6075910,
#'                          SELECT_COMORBIDITY = c("chf","carit"),
#'                          PERCENT_CUT_OFF = 30,
#'                          PRESCRIPTION = VO_ready,
#'                          PRESCRIPTION_ATC_COLNAME = "ATC",
#'                          PRESCRIPTION_ID_COLNAME = "Versid",
#'                          DIAGNOSES = Diag_ready,
#'                          DIAGNOSES_ICD_COLNAME = "ICD",
#'                          DIAGNOSES_ID_COLNAME = "Versid.x",
#'                          DIAGNOSES_ICD_TYPE = "icd10",
#'                          INSURANTS = VERS_ready,
#'                          INSURANTS_ID_COLNAME = "Versid",
#'                          INSURANTS_BIRTH_YEAR_COLNAME = "Geburtsjahr",
#'                          INSURANTS_SEX_COLNAME = "Geschlecht",
#'                          INSURANTS_INDEXDATE_COLNAME = "datumIndex")
#'
#'
#'i <- Find_Similar(PATIENT_SELECTION = "NEW",
#'                  ANALYSIS_TYPE = "CLUSTER",
#'                  DISTANCE_MEASURE = "GOWER",
#'                  SELECT_COMORBIDITY = c("chf","carit"),
#'                  PATIENT_SIMILAR_BIRTH_YEAR = 1930,
#'                  PATIENT_SIMILAR_SEX = "1",
#'                  PATIENT_SIMILAR_INDEXDATE = "20191030",
#'                  PATIENT_SIMILAR_INDEXDATE_FORMAT = "%Y%m%d",
#'                  PATIENT_SIMILAR_ATC = c("^C10"),
#'                  PATIENT_SIMILAR_ICD = c("I480","I101"),
#'                  PRESCRIPTION = VO_ready,
#'                  PRESCRIPTION_ATC_COLNAME = "ATC",
#'                  PRESCRIPTION_ID_COLNAME = "Versid",
#'                  DIAGNOSES = Diag_ready,
#'                  DIAGNOSES_ICD_COLNAME = "ICD",
#'                  DIAGNOSES_ID_COLNAME = "Versid.x",
#'                  DIAGNOSES_ICD_TYPE = "icd10",
#'                  INSURANTS = VERS_ready,
#'                  INSURANTS_ID_COLNAME = "Versid",
#'                  INSURANTS_BIRTH_YEAR_COLNAME = "Geburtsjahr",
#'                  INSURANTS_SEX_COLNAME = "Geschlecht",
#'                  INSURANTS_INDEXDATE_COLNAME = "datumIndex")
#'
#'
#' @export
Find_Similar <- function(PATIENT_SIMILAR_ATC_COUNT=c(1), PERCENT_CUT_OFF = 30, PATIENT_SELECTION = c(),PATIENT_SELECTION_ID = c(), PAT_SIMILAR_ID = 999999999999, ANALYSIS_TYPE = "NEAREST", DISTANCE_MEASURE = "GOWER", NEAREST_PERCENT_AMOUNT = 10, SELECT_MAX_CLUSTERS = 30, PATIENT_SIMILAR_INDEXDATE = c("99991231"), PATIENT_SIMILAR_INDEXDATE_FORMAT = c("%Y%m%d"), PATIENT_SIMILAR_BIRTH_YEAR = c(9999), PATIENT_DIAGNOSE_EXTRA_WEIGHT =c(), PATIENT_SIMILAR_SEX = c(3),PATIENT_SIMILAR_ATC = c("ZZZ"),PATIENT_SIMILAR_ICD = c("Z"),PRESCRIPTION = c(),PRESCRIPTION_ATC_COLNAME = c(),PRESCRIPTION_ID_COLNAME = c(),DIAGNOSES = c(),DIAGNOSES_ICD_COLNAME = c(),DIAGNOSES_ID_COLNAME = c(),INSURANTS,INSURANTS_ID_COLNAME = c(),INSURANTS_BIRTH_YEAR_COLNAME = c(), DIAGNOSES_ICD_TYPE = c("icd10"), INSURANTS_SEX_COLNAME = c(), INSURANTS_INDEXDATE_COLNAME = c(), SELECT_COMORBIDITY = c("carit")){
  options(warn=-1)
  progress(0, max.value = 10, progress.bar = TRUE, char = "|",init = TRUE, console = TRUE, gui = TRUE)
  #______________________________________________________________________________________Cases and Varcheck
  vector.is.empty <- function(x) return(length(x) ==0)
  if(vector.is.empty(INSURANTS_BIRTH_YEAR_COLNAME)==TRUE){INSURANTS$BIRTHYEAR <- 9999}else{INSURANTS$BIRTHYEAR <- INSURANTS[[INSURANTS_BIRTH_YEAR_COLNAME]]}
  if(vector.is.empty(INSURANTS_SEX_COLNAME)==TRUE){INSURANTS$GESCHLECHT <- 1}else{INSURANTS$GESCHLECHT <- INSURANTS[[INSURANTS_SEX_COLNAME]]}
  if(vector.is.empty(DIAGNOSES_ICD_COLNAME)==TRUE){DIAGNOSES$ICD <- "Z"}else{DIAGNOSES$DIAGNOSES_ICD_COLNAME <- DIAGNOSES[[DIAGNOSES_ICD_COLNAME]]}
  if(vector.is.empty(PRESCRIPTION_ATC_COLNAME)==TRUE){PRESCRIPTION$ATC <- "Z"}else{PRESCRIPTION$PRESCRIPTION_ATC_COLNAME <- PRESCRIPTION[[PRESCRIPTION_ATC_COLNAME]]}

  if(vector.is.empty(PATIENT_SELECTION)==TRUE){stop("Please Enter PATIENT_SELECTION")}
  if(PATIENT_SELECTION == "NEW"){

    INSURANTS$ID <- INSURANTS[[INSURANTS_ID_COLNAME]]

    if(vector.is.empty(INSURANTS_INDEXDATE_COLNAME) == TRUE){INSURANTS$INDEX <- as.Date("99991231", format = "%Y%m%d")}else{INSURANTS$INDEX <- INSURANTS[[INSURANTS_INDEXDATE_COLNAME]]}

    if(PATIENT_SIMILAR_BIRTH_YEAR ==9999){INSURANTS$BIRTHYEAR <- 9999}
    if(PATIENT_SIMILAR_SEX==3){INSURANTS$GESCHLECHT <- 3}
    if(PATIENT_SIMILAR_INDEXDATE=="99991231"){INSURANTS$INDEX <- as.Date("99991231", format = "%Y%m%d")}
    if(PATIENT_SIMILAR_INDEXDATE_FORMAT=="%Y%m%d"){PATIENT_SIMILAR_INDEXDATE_FORMAT <- "%Y%m%d"}
    if(PATIENT_SIMILAR_ATC=="ZZZ"){PRESCRIPTION$ATC <- "ZZZ"}
    if(PATIENT_SIMILAR_ICD=="Z"){DIAGNOSES$ICD <- "Z"}

    if(vector.is.empty(PATIENT_SIMILAR_BIRTH_YEAR) == FALSE && is.numeric(PATIENT_SIMILAR_BIRTH_YEAR)==FALSE){stop("PATIENT_SIMILAR_BIRTH_YEAR must be a NUMERIC Argument")}
    if(vector.is.empty(PATIENT_SIMILAR_SEX) == FALSE && is.numeric(PATIENT_SIMILAR_SEX)==FALSE){stop("PATIENT_SIMILAR_SEX must be a Numeric Argument")}
    if(vector.is.empty(PATIENT_SIMILAR_INDEXDATE) == FALSE && is.character(PATIENT_SIMILAR_INDEXDATE)==FALSE){stop("PATIENT_SIMILAR_INDEXDATE must be a CHARACTER Argument")}
    if(vector.is.empty(PATIENT_SIMILAR_INDEXDATE_FORMAT) == FALSE && is.character(PATIENT_SIMILAR_INDEXDATE_FORMAT)==FALSE){stop("PATIENT_SIMILAR_INDEXDATE_FORMAT must be a CHARACTER Argument")}
    if(vector.is.empty(PATIENT_SIMILAR_ATC) == FALSE && is.character(PATIENT_SIMILAR_ATC)==FALSE){stop("PATIENT_SIMILAR_ATC must be a CHARACTER Argument")}
    if(vector.is.empty(PATIENT_SIMILAR_ICD) == FALSE && is.character(PATIENT_SIMILAR_ICD)==FALSE){stop("PATIENT_SIMILAR_ICD must be a CHARACTER Argument")}

    if(vector.is.empty(PATIENT_SIMILAR_ATC_COUNT)==FALSE){
      if(is.numeric(PATIENT_SIMILAR_ATC_COUNT) == FALSE){
        stop("Please Enter PATIENT_SIMILAR_ATC_COUNT must be an NUMERIC Argument")
      }}
    if(vector.is.empty(PATIENT_DIAGNOSE_EXTRA_WEIGHT)==FALSE){
      if(is.character(PATIENT_DIAGNOSE_EXTRA_WEIGHT) == FALSE){
        stop("Please Enter PATIENT_DIAGNOSE_EXTRA_WEIGHT must be an CHARACTER Argument")
      }}

    if(vector.is.empty(ANALYSIS_TYPE)==TRUE){stop("Please Enter ANALYSIS_TYPE")}
    if(vector.is.empty(DISTANCE_MEASURE)==TRUE){stop("Please Enter DISTANCE_MEASURE")}

    if(ANALYSIS_TYPE == "NEAREST"){}
    else if(ANALYSIS_TYPE == "CLUSTER"){}
    else {stop("ANALYSIS_TYPE must be NEAREST or CLUSTER")}

    if(DISTANCE_MEASURE == "GOWER"){}
    else if(DISTANCE_MEASURE == "HEOM"){}
    else {stop("DISTANCE_MEASURE must be GOWER or HEOM")}

    for (i in 1:length(SELECT_COMORBIDITY)) {
      if (SELECT_COMORBIDITY[i] == "chf"){}
      else if (SELECT_COMORBIDITY[i] == "carit"){}
      else if (SELECT_COMORBIDITY[i] == "valv"){}
      else if (SELECT_COMORBIDITY[i] == "pcd"){}
      else if (SELECT_COMORBIDITY[i] == "pvd"){}
      else if (SELECT_COMORBIDITY[i] == "hypunc"){}
      else if (SELECT_COMORBIDITY[i] == "hypc"){}
      else if (SELECT_COMORBIDITY[i] == "para"){}
      else if (SELECT_COMORBIDITY[i] == "ond"){}
      else if (SELECT_COMORBIDITY[i] == "cpd"){}
      else if (SELECT_COMORBIDITY[i] == "diabunc"){}
      else if (SELECT_COMORBIDITY[i] == "diabc"){}
      else if (SELECT_COMORBIDITY[i] == "hypothy"){}
      else if (SELECT_COMORBIDITY[i] == "rf"){}
      else if (SELECT_COMORBIDITY[i] == "ld"){}
      else if (SELECT_COMORBIDITY[i] == "pud"){}
      else if (SELECT_COMORBIDITY[i] == "aids"){}
      else if (SELECT_COMORBIDITY[i] == "lymph"){}
      else if (SELECT_COMORBIDITY[i] == "metacanc"){}
      else if (SELECT_COMORBIDITY[i] == "solidtum"){}
      else if (SELECT_COMORBIDITY[i] == "rheumd"){}
      else if (SELECT_COMORBIDITY[i] == "coag"){}
      else if (SELECT_COMORBIDITY[i] == "obes"){}
      else if (SELECT_COMORBIDITY[i] == "wloss"){}
      else if (SELECT_COMORBIDITY[i] == "fed"){}
      else if (SELECT_COMORBIDITY[i] == "blane"){}
      else if (SELECT_COMORBIDITY[i] == "dane"){}
      else if (SELECT_COMORBIDITY[i] == "alcohol"){}
      else if (SELECT_COMORBIDITY[i] == "drug"){}
      else if (SELECT_COMORBIDITY[i] == "psycho"){}
      else if (SELECT_COMORBIDITY[i] == "depre"){}
      else if (SELECT_COMORBIDITY[i] == "score"){}
      else if (SELECT_COMORBIDITY[i] == "index"){}
      else if (SELECT_COMORBIDITY[i] == "wscore_ahrq"){}
      else if (SELECT_COMORBIDITY[i] == "wscore_vw"){}
      else if (SELECT_COMORBIDITY[i] == "windex_ahrq"){}
      else if (SELECT_COMORBIDITY[i] == "windex_vw"){}
      else {stop("SELECT_COMORBIDITY must be chf, carit, valv, pcd, pvd, hypunc, hypc, para, ond, cpd, diabunc, diabc, hypothy, rf, ld, pud, aids, lymph, metacanc, solidtum, rheumd, coag, obes, wloss, fed, blane, dane, alcohol, drug, psycho, depre, score, index, wscore_ahrq, wscore_vw, windex_ahrq or windex_vw")}
    }

    if(vector.is.empty(PRESCRIPTION)==TRUE){stop("Please Enter PRESCRIPTION")}
    if(vector.is.empty(PRESCRIPTION_ID_COLNAME)==TRUE){stop("Please Enter PRESCRIPTION_ID_COLNAME")}

    if(vector.is.empty(DIAGNOSES)==TRUE){stop("Please Enter DIAGNOSES")}
    if(vector.is.empty(DIAGNOSES_ID_COLNAME)==TRUE){stop("Please Enter DIAGNOSES_ID_COLNAME")}

    if(vector.is.empty(INSURANTS)==TRUE){stop("Please Enter INSURANTS")}
    if(vector.is.empty(INSURANTS_ID_COLNAME)==TRUE){stop("Please Enter INSURANTS_ID_COLNAME")}

    if(is.character(PRESCRIPTION_ID_COLNAME)==FALSE){stop("PRESCRIPTION_ID_COLNAME must be a CHARACTER Argument")}

    if(is.character(DIAGNOSES_ID_COLNAME)==FALSE){stop("DIAGNOSES_ID_COLNAME must be a CHARACTER Argument")}

    if(is.character(INSURANTS_ID_COLNAME)==FALSE){stop("INSURANTS_ID_COLNAME must be a CHARACTER Argument")}

    if(DIAGNOSES_ICD_TYPE == "icd10"){}
    else if(DIAGNOSES_ICD_TYPE == "icd9"){}
    else(stop("DIAGNOSES_ICD_TYPE must be icd10 or icd9"))

  }
  else if(PATIENT_SELECTION == "IN_DF"){

    if(vector.is.empty(PATIENT_SELECTION_ID)==TRUE){stop("Please Enter PATIENT_SELECTION_ID")}
    if(is.numeric(PATIENT_SELECTION_ID)==FALSE){stop("PATIENT_SELECTION_ID must be a NUMERIC Argument")}

    if(vector.is.empty(ANALYSIS_TYPE)==TRUE){stop("Please Enter ANALYSIS_TYPE")}
    if(vector.is.empty(DISTANCE_MEASURE)==TRUE){stop("Please Enter DISTANCE_MEASURE")}

    if(ANALYSIS_TYPE == "NEAREST"){}
    else if(ANALYSIS_TYPE == "CLUSTER"){}
    else {stop("ANALYSIS_TYPE must be NEAREST or CLUSTER")}

    if(DISTANCE_MEASURE == "GOWER"){}
    else if(DISTANCE_MEASURE == "HEOM"){}
    else {stop("DISTANCE_MEASURE must be GOWER or HEOM")}

    for (i in 1:length(SELECT_COMORBIDITY)) {
      if (SELECT_COMORBIDITY[i] == "chf"){}
      else if (SELECT_COMORBIDITY[i] == "carit"){}
      else if (SELECT_COMORBIDITY[i] == "valv"){}
      else if (SELECT_COMORBIDITY[i] == "pcd"){}
      else if (SELECT_COMORBIDITY[i] == "pvd"){}
      else if (SELECT_COMORBIDITY[i] == "hypunc"){}
      else if (SELECT_COMORBIDITY[i] == "hypc"){}
      else if (SELECT_COMORBIDITY[i] == "para"){}
      else if (SELECT_COMORBIDITY[i] == "ond"){}
      else if (SELECT_COMORBIDITY[i] == "cpd"){}
      else if (SELECT_COMORBIDITY[i] == "diabunc"){}
      else if (SELECT_COMORBIDITY[i] == "diabc"){}
      else if (SELECT_COMORBIDITY[i] == "hypothy"){}
      else if (SELECT_COMORBIDITY[i] == "rf"){}
      else if (SELECT_COMORBIDITY[i] == "ld"){}
      else if (SELECT_COMORBIDITY[i] == "pud"){}
      else if (SELECT_COMORBIDITY[i] == "aids"){}
      else if (SELECT_COMORBIDITY[i] == "lymph"){}
      else if (SELECT_COMORBIDITY[i] == "metacanc"){}
      else if (SELECT_COMORBIDITY[i] == "solidtum"){}
      else if (SELECT_COMORBIDITY[i] == "rheumd"){}
      else if (SELECT_COMORBIDITY[i] == "coag"){}
      else if (SELECT_COMORBIDITY[i] == "obes"){}
      else if (SELECT_COMORBIDITY[i] == "wloss"){}
      else if (SELECT_COMORBIDITY[i] == "fed"){}
      else if (SELECT_COMORBIDITY[i] == "blane"){}
      else if (SELECT_COMORBIDITY[i] == "dane"){}
      else if (SELECT_COMORBIDITY[i] == "alcohol"){}
      else if (SELECT_COMORBIDITY[i] == "drug"){}
      else if (SELECT_COMORBIDITY[i] == "psycho"){}
      else if (SELECT_COMORBIDITY[i] == "depre"){}
      else if (SELECT_COMORBIDITY[i] == "score"){}
      else if (SELECT_COMORBIDITY[i] == "index"){}
      else if (SELECT_COMORBIDITY[i] == "wscore_ahrq"){}
      else if (SELECT_COMORBIDITY[i] == "wscore_vw"){}
      else if (SELECT_COMORBIDITY[i] == "windex_ahrq"){}
      else if (SELECT_COMORBIDITY[i] == "windex_vw"){}
      else {stop("SELECT_COMORBIDITY must be chf, carit, valv, pcd, pvd, hypunc, hypc, para, ond, cpd, diabunc, diabc, hypothy, rf, ld, pud, aids, lymph, metacanc, solidtum, rheumd, coag, obes, wloss, fed, blane, dane, alcohol, drug, psycho, depre, score, index, wscore_ahrq, wscore_vw, windex_ahrq or windex_vw")}
    }

    if(vector.is.empty(PRESCRIPTION)==TRUE){stop("Please Enter PRESCRIPTION")}
    if(vector.is.empty(PRESCRIPTION_ATC_COLNAME)==TRUE){stop("Please Enter PRESCRIPTION_ATC_COLNAME")}
    if(vector.is.empty(PRESCRIPTION_ID_COLNAME)==TRUE){stop("Please Enter PRESCRIPTION_ID_COLNAME")}
    if(vector.is.empty(DIAGNOSES)==TRUE){stop("Please Enter DIAGNOSES")}
    if(vector.is.empty(DIAGNOSES_ICD_COLNAME)==TRUE){stop("Please Enter DIAGNOSES_ICD_COLNAME")}
    if(vector.is.empty(DIAGNOSES_ID_COLNAME)==TRUE){stop("Please Enter DIAGNOSES_ID_COLNAME")}
    if(vector.is.empty(DIAGNOSES_ICD_TYPE)==TRUE){stop("Please Enter DIAGNOSES_ICD_TYPE")}
    if(vector.is.empty(INSURANTS)==TRUE){stop("Please Enter INSURANTS")}
    if(vector.is.empty(INSURANTS_ID_COLNAME)==TRUE){stop("Please Enter INSURANTS_ID_COLNAME")}
    if(vector.is.empty(INSURANTS_INDEXDATE_COLNAME)==TRUE){stop("Please Enter INSURANTS_INDEXDATE_COLNAME")}

    if(is.character(PRESCRIPTION_ATC_COLNAME)==FALSE){stop("PRESCRIPTION_ATC_COLNAME must be a CHARACTER Argument")}
    if(is.character(PRESCRIPTION_ID_COLNAME)==FALSE){stop("PRESCRIPTION_ID_COLNAME must be a CHARACTER Argument")}
    if(is.character(DIAGNOSES_ICD_COLNAME)==FALSE){stop("DIAGNOSES_ICD_COLNAME must be a CHARACTER Argument")}
    if(is.character(DIAGNOSES_ID_COLNAME)==FALSE){stop("DIAGNOSES_ID_COLNAME must be a CHARACTER Argument")}
    if(is.character(DIAGNOSES_ICD_TYPE)==FALSE){stop("DIAGNOSES_ICD_TYPE must be a CHARACTER Argument")}
    if(is.character(INSURANTS_ID_COLNAME)==FALSE){stop("INSURANTS_ID_COLNAME must be a CHARACTER Argument")}
    if(is.character(INSURANTS_INDEXDATE_COLNAME)==FALSE){stop("INSURANTS_INDEXDATE_COLNAME must be a CHARACTER Argument")}

    if(DIAGNOSES_ICD_TYPE == "icd10"){}
    else if(DIAGNOSES_ICD_TYPE == "icd9"){}
    else(stop("DIAGNOSES_ICD_TYPE must be icd10 or icd9"))

    if(vector.is.empty(INSURANTS_INDEXDATE_COLNAME) == TRUE){INSURANTS$INDEX <- as.Date("99991231", format = "%Y%m%d")}else{INSURANTS$INDEX <- INSURANTS[[INSURANTS_INDEXDATE_COLNAME]]}

  }
  else {stop("PATIENT_SELECTION must be NEW or IN_DF")}

  progress(1, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

  #______________________________________________________________________________________Define Functions
  calcGowerPat <- function(datalist) {
    ID1 <- PatToMatch$id
    ID2 <- datalist$id

    df <- bind_rows(PatToMatch,datalist)

    gower.dissimilarity.mtrx <- suppressWarnings(daisy(df, metric = c("gower")))
    dissimilarity.mtrx.csv.content = as.matrix(gower.dissimilarity.mtrx)
    dissimilarity.mtrx.csv.content <- data.frame(dissimilarity.mtrx.csv.content)

    gowercount <- dissimilarity.mtrx.csv.content$X1[2]

    dfr <- data.frame(ID1,ID2,gowercount)

    return(dfr)
  }
  searchATCGower <- function(datalist,ATCsearch) {
    ATCgower <- datalist
    ID <- unique(ATCgower$ID)
    Erg <- 0
    ATCgower <- filter(ATCgower, grepl(ATCsearch, ATCgower$ATC))
    AnzahlVO <- nrow(ATCgower)
    if(nrow(ATCgower)>0){
      Erg <- 1
    }else{
      Erg <- 0
    }
    df <- data.frame(ID,AnzahlVO,Erg)
    return(df)
  }
  searchICDGower <- function(datalist) {
    ICDgower <- datalist
    id <- unique(ICDgower$id)
    Erg <- 0
    ICDgower <- filter(ICDgower, grepl(ICDsearch, ICDgower$code))
    if(nrow(ICDgower)>0){
      Erg <- 1
    }else{
      Erg <- 0
    }
    df <- data.frame(id,Erg)
    return(df)
  }
  PatDat <- function(datalist) {

    patient <- datalist
    id <- unique(patient$ID)
    sex <- unique(patient$GESCHLECHT)
    patient$INDEX <- format(patient$INDEX, "%Y")
    patient$INDEX <- as.numeric(patient$INDEX)
    age <- unique(patient$INDEX)-unique(patient$BIRTHYEAR)

    df <- data.frame(id,sex,age)
    return(df)
  }

  progress(2, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

  #______________________________________________________________________________________Define Variables
  #PRESCRIPTION$ATC <- PRESCRIPTION[[PRESCRIPTION_ATC_COLNAME]]
  #PRESCRIPTION$ID <- PRESCRIPTION[[PRESCRIPTION_ID_COLNAME]]

  #PRESCRIPTION <- PRESCRIPTION %>%
  #  select(ID,ATC)

  #DIAGNOSES$ICD <- DIAGNOSES[[DIAGNOSES_ICD_COLNAME]]
  #DIAGNOSES$ID <- DIAGNOSES[[DIAGNOSES_ID_COLNAME]]

  #DIAGNOSES <- DIAGNOSES %>%
  #  select(ID,ICD)

  if(vector.is.empty(INSURANTS_BIRTH_YEAR_COLNAME)==TRUE){INSURANTS$BIRTHYEAR <- 9999}else{INSURANTS$BIRTHYEAR <- INSURANTS[[INSURANTS_BIRTH_YEAR_COLNAME]]}
  if(vector.is.empty(INSURANTS_SEX_COLNAME)==TRUE){INSURANTS$GESCHLECHT <- 1}else{INSURANTS$GESCHLECHT <- INSURANTS[[INSURANTS_SEX_COLNAME]]}

  INSURANTS <- INSURANTS %>%
    select(ID,BIRTHYEAR,GESCHLECHT,INDEX) %>%
    distinct()


  if(PATIENT_SELECTION == "NEW"){
    if(is.character(PATIENT_SIMILAR_INDEXDATE) == FALSE){
      PATIENT_SIMILAR_INDEXDATE <- as.character(PATIENT_SIMILAR_INDEXDATE)
    }
    if(is.character(PATIENT_SIMILAR_INDEXDATE_FORMAT) == FALSE){
      PATIENT_SIMILAR_INDEXDATE_FORMAT <- as.character(PATIENT_SIMILAR_INDEXDATE_FORMAT)
    }

    PATIENT_SIMILAR_INDEXDATE <- as.Date(PATIENT_SIMILAR_INDEXDATE,PATIENT_SIMILAR_INDEXDATE_FORMAT)

    #______________________________________________________________________________________Add Patient to find others for to Dataframes
    PATIENT_SIMILAR_ATC2 <- gsub("^", "",PATIENT_SIMILAR_ATC, fixed = TRUE)

    PAT_SIMILAR_ID <- PAT_SIMILAR_ID
    PAT_SIMILAR_DIAGNOSES <- data.frame(PAT_SIMILAR_ID,PATIENT_SIMILAR_ICD)
    PAT_SIMILAR_VO <- data.frame()

    for (i in 1:length(PATIENT_SIMILAR_ATC2)) {
      a <-  PATIENT_SIMILAR_ATC_COUNT[i]
      for (j in 1:a){
        PAT_SIMILAR_VO_ub <- data.frame(PAT_SIMILAR_ID,PATIENT_SIMILAR_ATC2[i])
        PAT_SIMILAR_VO <- bind_rows(PAT_SIMILAR_VO_ub, PAT_SIMILAR_VO)
      }
    }

    PAT_SIMILAR_PAT <- data.frame(PAT_SIMILAR_ID, PATIENT_SIMILAR_SEX, PATIENT_SIMILAR_BIRTH_YEAR, PATIENT_SIMILAR_INDEXDATE)

    if(is.character(PAT_SIMILAR_DIAGNOSES$PATIENT_SIMILAR_ICD) == FALSE){
      PAT_SIMILAR_DIAGNOSES$PATIENT_SIMILAR_ICD <- as.character(PAT_SIMILAR_DIAGNOSES$PATIENT_SIMILAR_ICD)
    }
    if(is.character(PAT_SIMILAR_VO$PATIENT_SIMILAR_ATC) == FALSE){
      PAT_SIMILAR_VO$PATIENT_SIMILAR_ATC2.i. <- as.character(PAT_SIMILAR_VO$PATIENT_SIMILAR_ATC2.i.)
    }
    if(is.numeric(PAT_SIMILAR_PAT$PATIENT_SIMILAR_SEX) == FALSE){
      PAT_SIMILAR_PAT$PATIENT_SIMILAR_SEX <- as.numeric(PAT_SIMILAR_PAT$PATIENT_SIMILAR_SEX)
    }
    if(is.numeric(PAT_SIMILAR_PAT$PATIENT_SIMILAR_BIRTH_YEAR) == FALSE){
      PAT_SIMILAR_PAT$PATIENT_SIMILAR_BIRTH_YEAR <- as.numeric(PAT_SIMILAR_PAT$PATIENT_SIMILAR_BIRTH_YEAR)
    }

    PAT_SIMILAR_DIAGNOSES <- PAT_SIMILAR_DIAGNOSES %>%
      rename(ID = PAT_SIMILAR_ID, ICD = PATIENT_SIMILAR_ICD)

    PAT_SIMILAR_VO <- PAT_SIMILAR_VO %>%
      rename(ID = PAT_SIMILAR_ID, ATC = PATIENT_SIMILAR_ATC2.i.)

    PAT_SIMILAR_PAT <- PAT_SIMILAR_PAT %>%
      rename(ID = PAT_SIMILAR_ID, GESCHLECHT = PATIENT_SIMILAR_SEX, BIRTHYEAR = PATIENT_SIMILAR_BIRTH_YEAR, INDEX = PATIENT_SIMILAR_INDEXDATE)

    DIAGNOSES <- bind_rows(DIAGNOSES, PAT_SIMILAR_DIAGNOSES)
    PRESCRIPTION <- bind_rows(PRESCRIPTION, PAT_SIMILAR_VO)
    INSURANTS <- bind_rows(INSURANTS,PAT_SIMILAR_PAT)
  }
  if(PATIENT_SELECTION == "IN_DF"){

    PAT_TO_MATCH <- PRESCRIPTION %>%
      filter(PRESCRIPTION$ID == PATIENT_SELECTION_ID)
    PAT_TO_MATCH$ID <- PAT_SIMILAR_ID
    PRESCRIPTION <- PRESCRIPTION %>%
      filter(PRESCRIPTION$ID != PATIENT_SELECTION_ID)
    PRESCRIPTION <- bind_rows(PRESCRIPTION,PAT_TO_MATCH)

    PAT_TO_MATCH <- DIAGNOSES %>%
      filter(DIAGNOSES$ID == PATIENT_SELECTION_ID)
    PAT_TO_MATCH$ID <- PAT_SIMILAR_ID

    DIAGNOSES <- DIAGNOSES %>%
      filter(DIAGNOSES$ID != PATIENT_SELECTION_ID)
    DIAGNOSES <- bind_rows(DIAGNOSES,PAT_TO_MATCH)

    PAT_TO_MATCH <- INSURANTS %>%
      filter(INSURANTS$ID == PATIENT_SELECTION_ID)
    PAT_TO_MATCH$ID <- PAT_SIMILAR_ID
    INSURANTS <- INSURANTS %>%
      filter(INSURANTS$ID != PATIENT_SELECTION_ID)
    INSURANTS <- bind_rows(INSURANTS,PAT_TO_MATCH)
  }

  DIAGNOSES <- DIAGNOSES %>%
    rename(id = ID, code=ICD)

  progress(3, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

  #______________________________________________________________________________________Calculate Commorbidity-Matrix

  COMORBIDITY_MATRIX <- comorbidity(x = DIAGNOSES, id = "id", code = "code", score = "elixhauser", icd = DIAGNOSES_ICD_TYPE, assign0 = FALSE)

  COMORBIDITY_MATRIX <- COMORBIDITY_MATRIX %>%
    select(id,SELECT_COMORBIDITY,score,index)

  progress(4, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

  if(PATIENT_SELECTION == "NEW"){

    if(is.character(PATIENT_SIMILAR_ATC) == FALSE){
      PATIENT_SIMILAR_ATC <- as.character(PATIENT_SIMILAR_ATC)
    }
    datalist <- split(PRESCRIPTION,PRESCRIPTION$ID)
    for (i in 1:length(PATIENT_SIMILAR_ATC)) {
      ATCsearch <- PATIENT_SIMILAR_ATC[i]
      datalist2 <- map(datalist,searchATCGower,ATCsearch)
      gower1ATC <- rbindlist(datalist2)
      gower1ATC <- gower1ATC %>%
        rename(id = ID)
      COMORBIDITY_MATRIX <- merge(COMORBIDITY_MATRIX,gower1ATC, by = "id")
      namenspalten <- names(COMORBIDITY_MATRIX)
      namenspalten <- namenspalten[-length(namenspalten)]
      namenspalten <- namenspalten[-length(namenspalten)]
      namenspalten <- append(namenspalten, paste("Count VO",ATCsearch))
      namenspalten <- append(namenspalten, ATCsearch)
      colnames(COMORBIDITY_MATRIX) <- namenspalten
    }

    if(vector.is.empty(PATIENT_DIAGNOSE_EXTRA_WEIGHT)==FALSE){
      datalist <- split(DIAGNOSES,DIAGNOSES$id)
      for (i in 1:length(PATIENT_DIAGNOSE_EXTRA_WEIGHT)) {
        ICDsearch <- PATIENT_DIAGNOSE_EXTRA_WEIGHT[i]
        datalist2 <- map(datalist,searchICDGower)
        gower1ICD <- rbindlist(datalist2)
        COMORBIDITY_MATRIX <- merge(COMORBIDITY_MATRIX,gower1ICD, by = "id")
        namenspalten <- names(COMORBIDITY_MATRIX)
        namenspalten <- namenspalten[-length(namenspalten)]
        namenspalten <- append(namenspalten, ICDsearch)
        colnames(COMORBIDITY_MATRIX) <- namenspalten
      }}
  }
  if(PATIENT_SELECTION == "IN_DF"){

    PATIENT_SIMILAR_ATC <- PRESCRIPTION %>%
      filter(PRESCRIPTION$ID == PAT_SIMILAR_ID)
    PATIENT_SIMILAR_ATC <- PATIENT_SIMILAR_ATC$ATC
    PATIENT_DIAGNOSE_EXTRA_WEIGHT <- DIAGNOSES %>%
      filter(DIAGNOSES$id == PAT_SIMILAR_ID)
    PATIENT_DIAGNOSE_EXTRA_WEIGHT <- PATIENT_DIAGNOSE_EXTRA_WEIGHT$code

    if(is.character(PATIENT_SIMILAR_ATC) == FALSE){
      PATIENT_SIMILAR_ATC <- as.character(PATIENT_SIMILAR_ATC)
    }
    if(is.character(PATIENT_DIAGNOSE_EXTRA_WEIGHT) == FALSE){
      PATIENT_DIAGNOSE_EXTRA_WEIGHT <- as.character(PATIENT_DIAGNOSE_EXTRA_WEIGHT)
    }

    PATIENT_SIMILAR_ATC <- PATIENT_SIMILAR_ATC[!is.na(PATIENT_SIMILAR_ATC)]
    PATIENT_DIAGNOSE_EXTRA_WEIGHT <- PATIENT_DIAGNOSE_EXTRA_WEIGHT[!is.na(PATIENT_DIAGNOSE_EXTRA_WEIGHT)]

    PATIENT_SIMILAR_ATC <- unique(PATIENT_SIMILAR_ATC)
    PATIENT_DIAGNOSE_EXTRA_WEIGHT <- unique(PATIENT_DIAGNOSE_EXTRA_WEIGHT)

    datalist <- split(PRESCRIPTION,PRESCRIPTION$ID)

    for (i in 1:length(PATIENT_SIMILAR_ATC)) {
      ATCsearch <- PATIENT_SIMILAR_ATC[i]

      datalist2 <- map(datalist,searchATCGower,ATCsearch)
      gower1ATC <- rbindlist(datalist2)
      gower1ATC <- gower1ATC %>%
        rename(id = ID)
      COMORBIDITY_MATRIX <- merge(COMORBIDITY_MATRIX,gower1ATC, by = "id")
      namenspalten <- names(COMORBIDITY_MATRIX)
      namenspalten <- namenspalten[-length(namenspalten)]
      namenspalten <- namenspalten[-length(namenspalten)]
      namenspalten <- append(namenspalten, paste("Count VO",ATCsearch))
      namenspalten <- append(namenspalten, ATCsearch)
      colnames(COMORBIDITY_MATRIX) <- namenspalten

    }
    datalist <- split(DIAGNOSES,DIAGNOSES$id)
    for (i in 1:length(PATIENT_DIAGNOSE_EXTRA_WEIGHT)) {
      ICDsearch <- PATIENT_DIAGNOSE_EXTRA_WEIGHT[i]

      datalist2 <- map(datalist,searchICDGower)
      gower1ICD <- rbindlist(datalist2)
      COMORBIDITY_MATRIX <- merge(COMORBIDITY_MATRIX,gower1ICD, by = "id")
      namenspalten <- names(COMORBIDITY_MATRIX)
      namenspalten <- namenspalten[-length(namenspalten)]
      namenspalten <- append(namenspalten, ICDsearch)
      colnames(COMORBIDITY_MATRIX) <- namenspalten

    }
  }


  datalist <- split(INSURANTS,INSURANTS$ID)
  datalist <- map(datalist,PatDat)
  patdaten <- rbindlist(datalist)
  patdaten <- patdaten %>%
    distinct()
  COMORBIDITY_MATRIX <- merge(COMORBIDITY_MATRIX,patdaten, by ="id")
  if(PATIENT_SIMILAR_ATC=="ZZZ"){COMORBIDITY_MATRIX$'Count VO ZZZ' <- 0}
  if(PATIENT_SIMILAR_ICD=="Z"){COMORBIDITY_MATRIX$score <- 1}

  progress(5, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
  #______________________________________________________________________________________Analysis

  if(ANALYSIS_TYPE == "CLUSTER"){
    #______________________________________________________________________________________Calculate Distance Matrix

    if(DISTANCE_MEASURE == "GOWER"){
      #anzvar <- length(COMORBIDITY_MATRIX[0,])
      DIST <- suppressWarnings(daisy(COMORBIDITY_MATRIX, metric = "gower"))
      MATRIX <- as.matrix(DIST)
    }
    if(DISTANCE_MEASURE == "HEOM"){
      #anzvar <- length(COMORBIDITY_MATRIX[0,])
      DIST <- distances(1,COMORBIDITY_MATRIX,"HEOM")
      MATRIX <- as.matrix(DIST)
    }
    progress(6, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

    #______________________________________________________________________________________Find Best Number of Clusters
    cores=detectCores()

    cl <- makeCluster(cores-1) #not to overload your computer

    registerDoParallel(cl)

    intermediate <- c(NA)

    intermediate <- foreach(i = 2:SELECT_MAX_CLUSTERS) %dopar% {
      pam_fit <- cluster::pam(DIST, diss = TRUE, k = i)
      pam_fit <- pam_fit$silinfo$avg.width
    }

    stopCluster(cl)

    sil_width <- c(NA)

    for(i in 1:(SELECT_MAX_CLUSTERS-1)){
      sil_width[i]<-intermediate[[i]]
    }

    K_Number <- c(2:SELECT_MAX_CLUSTERS)

    intermediate <- data.frame(K_Number,sil_width)

    plot(2:SELECT_MAX_CLUSTERS, intermediate$sil_width,
         xlab = "Number of clusters",
         ylab = "Silhouette Width")
    lines(2:SELECT_MAX_CLUSTERS, intermediate$sil_width)

    search <- max(intermediate$sil_width)

    intermediate <- intermediate %>%
      filter(intermediate$sil_width == search)

    k <- intermediate$K_Number
    progress(7, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
    #______________________________________________________________________________________Calculate Clusters

    pam_fit <- pam(DIST, diss = TRUE, k)
    #pam_results <- df %>%
    #  mutate(cluster = pam_fit$clustering) %>%
    #  group_by(cluster) %>%
    #  do(the_summary = summary(.))
    #pam_results$the_summary
    progress(8, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
    tsne_obj <- Rtsne(DIST, is_distance = TRUE)
    tsne_data <- tsne_obj$Y %>%
      data.frame() %>%
      setNames(c("X", "Y")) %>%
      mutate(cluster = factor(pam_fit$clustering))

    a <- ggplot(aes(x = X, y = Y), data = tsne_data) +
      geom_point(aes(color = cluster))
    plot(a)
    COMORBIDITY_MATRIX$clust <- pam_fit$clustering
    output <- COMORBIDITY_MATRIX
    progress(9, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
  }
  if(ANALYSIS_TYPE == "NEAREST"){
    progress(6, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
    calcGowerPat <- function(datalist,PatToMatch) {
      ID1 <- PatToMatch$id
      ID2 <- datalist$id
      df <- bind_rows(PatToMatch,datalist)
      anzvar <- length(df[0,])
      gower.dissimilarity.mtrx <- suppressWarnings(daisy(df[,2:anzvar], metric = c("gower")))
      dissimilarity.mtrx.csv.content = as.matrix(gower.dissimilarity.mtrx)
      dissimilarity.mtrx.csv.content <- data.frame(dissimilarity.mtrx.csv.content)
      gowercount <- dissimilarity.mtrx.csv.content$X1[2]
      dfr <- data.frame(ID1,ID2,gowercount)

      return(dfr)
    }
    calcHEOMPat <- function(datalist,PatToMatch) {
      ID1 <- PatToMatch$id
      ID2 <- datalist$id
      df <- bind_rows(PatToMatch,datalist)
      anzvar <- length(df[0,])
      gower.dissimilarity.mtrx <- distances(1,df[,2:anzvar],"HEOM")
      dissimilarity.mtrx.csv.content = as.matrix(gower.dissimilarity.mtrx)
      dissimilarity.mtrx.csv.content <- data.frame(dissimilarity.mtrx.csv.content)

      HEOMCount <- dissimilarity.mtrx.csv.content$X1[2]

      dfr <- data.frame(ID1,ID2,HEOMCount)

      return(dfr)
    }

    PatToMatch <- COMORBIDITY_MATRIX %>%
      filter(id == PAT_SIMILAR_ID)
    COMORBIDITY_MATRIX <- COMORBIDITY_MATRIX %>%
      filter(id != PAT_SIMILAR_ID)
    progress(7, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

    if(DISTANCE_MEASURE == "GOWER"){
      datalist <- split(COMORBIDITY_MATRIX, COMORBIDITY_MATRIX$id)
      datalist <- map(datalist,calcGowerPat,PatToMatch)
      gowerframe <- rbindlist(datalist)
      frame <- gowerframe %>%
        distinct()
    }
    progress(8, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

    if(DISTANCE_MEASURE == "HEOM"){
      datalist <- split(COMORBIDITY_MATRIX, COMORBIDITY_MATRIX$id)
      datalist <- map(datalist,calcHEOMPat,PatToMatch)
      gowerframe <- rbindlist(datalist)
      frame <- gowerframe %>%
        distinct()
    }
    progress(9, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)

    mengepat <- nrow(COMORBIDITY_MATRIX)
    anzahlbeste20percent <- as.integer(mengepat*(PERCENT_CUT_OFF/100))
    frame <- gowerframe[order(gowerframe[,3]),]
    frame <- frame[1:anzahlbeste20percent,]
    output <- frame
  }
  options(warn=0)
  progress(10, max.value = 10, progress.bar = TRUE, char = "|",init = FALSE, console = TRUE, gui = TRUE)
  return(output)
}



