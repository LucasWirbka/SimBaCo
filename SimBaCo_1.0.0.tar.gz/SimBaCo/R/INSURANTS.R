#' Insurant's master data of 10000 patients
#'
#' A dataset containing the Insurant's master data of almost 10000
#' patients. The variables are as follows:
#'
#' \itemize{
#'   \item ID ID's of the patients.
#'   \item SEX The SEX of the insured person.
#'   \item DATEOFBIRTH The year of birth of the insured person.
#'   \item DATEOFDEATH The date of death of the insured person.
#' }
#'
#' @docType data
#' @keywords datasets
#' @name INSURANTS
#' @usage data(INSURANTS)
#' @format A data frame with 176448 rows and 3 variables
NULL
