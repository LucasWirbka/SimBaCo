#' Prescriptions of 10000 patients
#'
#' A dataset containing the prescriptions and prescription dates of almost 10000
#' patients. The variables are as follows:
#'
#' \itemize{
#'   \item ID ID's of the patients.
#'   \item ATC The ATC-Code of the prescribed drug.
#'   \item DATE The date of issue of the prescription.
#' }
#'
#' @docType data
#' @keywords datasets
#' @name PRESCRIPTIONS
#' @usage data(PRESCRIPTIONS)
#' @format A data frame with 176448 rows and 3 variables
NULL
