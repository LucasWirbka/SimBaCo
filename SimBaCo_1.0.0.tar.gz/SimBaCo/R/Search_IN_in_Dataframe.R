#' Search in Dataframe Function
#'
#' Search in one datatframe according to another
#'
#' @import cluster
#' @import comorbidity
#' @import varhandle
#' @import dplyr
#' @import formattable
#' @import ggplot2
#' @import feather
#' @import purrr
#' @import data.table
#' @import shiny
#' @import rlist
#' @import RColorBrewer
#' @import gridExtra
#' @import forcats
#' @import furrr
#' @import foreach
#' @import doParallel
#' @import stringr
#' @import parallel
#' @import snow
#' @import survival
#' @import survminer
#' @import pROC
#' @import factoextra
#' @import readr
#' @import Rtsne
#' @import iterators
#' @import UBL
#' @import svMisc
#' @import lubridate
#'
#'
#' @param DF1 DF1, the name of the first dataframe
#' @param DF2 DF2, the name of the second dataframe
#' @param DF1_COLNAME DF1_COLNAME, the column in the dataframe DF1
#' @param DF2_COLNAME DF2_COLNAME, the column in the dataframe DF2
#'
#' @return All Data matched from DF1 in DF2 according to the two columns
#'
#' @author Lucas Wirbka, \email{Lucas.Wirbka@@med.uni-heidelberg.de}
#'
#' @examples
#'
#'Index_ready <- Search_IN_Dataframe(DF1 = VERS, DF1_COLNAME = "Versid", DF2 = Index, DF2_COLNAME = "Versid")
#'
#'
#' @export
Search_IN_Dataframe <- function(DF1 = c(),DF2 = c(), DF1_COLNAME = c(), DF2_COLNAME = c()) {

  vector.is.empty <- function(x) return(length(x) ==0)

  if(vector.is.empty(DF1)==TRUE){stop("Please Enter DF1")}
  if(vector.is.empty(DF2)==TRUE){stop("Please Enter DF2")}
  if(vector.is.empty(DF1_COLNAME)==TRUE){stop("Please Enter DF1_COLNAME")}
  if(vector.is.empty(DF2_COLNAME)==TRUE){stop("Please Enter DF2_COLNAME")}



  DFBACK <- DF1 %>% #FILTER all rows in Dataframe 1 according to Variable in DF2
    filter(DF1[[DF1_COLNAME]] %in% DF2[[DF2_COLNAME]])

  return(DFBACK)
}



